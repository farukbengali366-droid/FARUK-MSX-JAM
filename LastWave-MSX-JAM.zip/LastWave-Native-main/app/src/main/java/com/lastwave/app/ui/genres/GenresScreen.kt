package com.lastwave.app.ui.genres

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.lastwave.app.R
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lastwave.app.data.generate.GeneratedTrack
import com.lastwave.app.ui.common.ArtworkImage
import com.lastwave.app.ui.common.ExpressiveHeader
import com.lastwave.app.ui.common.GlassHeaderLayout
import com.lastwave.app.ui.common.TrackContextMenuSheet
import com.lastwave.app.ui.common.TrackMenuCapabilities
import com.lastwave.app.ui.common.TrackMenuTarget
import com.lastwave.app.ui.common.safeDrawingBottomPadding
import com.lastwave.app.ui.common.safeHorizontalContentPadding
import com.lastwave.app.ui.common.adaptiveContentWidth
import com.lastwave.app.ui.player.LocalMiniPlayerScrollClearance

/**
 * Faithful port of genres.js (§5): bar-chart genre list with a period
 * filter, and a Genre Detail bottom sheet (§5.3) with Start Mix / Discover
 * More actions and an infinite-scrolling, sortable track list reusing the
 * shared track context menu.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GenresScreen(
    onBack: () -> Unit = {},
    onNavigateToPlaylist: () -> Unit = {},
    viewModel: GenresViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(state.navigateToPlaylist) {
        if (state.navigateToPlaylist) {
            onNavigateToPlaylist()
            viewModel.consumeNavigateToPlaylist()
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        GlassHeaderLayout(
            Modifier
                .fillMaxSize()
                .adaptiveContentWidth(maxWidth = 860.dp),
            header = { headerModifier, headerBackdrop ->
            ExpressiveHeader(
                modifier = headerModifier,
                backdrop = headerBackdrop,
                title = stringResource(R.string.ge_title),
                subtitle = stringResource(R.string.ge_sub),
                onBack = onBack,
                actions = { PeriodDropdown(state.period, viewModel::setPeriod) },
            )
            },
        ) { headerInset ->
        Column(Modifier.fillMaxSize()) {

            when {
                state.isLoading -> Box(
                    Modifier.fillMaxSize().safeHorizontalContentPadding(),
                    contentAlignment = Alignment.Center,
                ) { com.lastwave.app.ui.common.ExpressiveLoadingIndicator() }
                state.stats.isEmpty() -> Box(
                    Modifier.fillMaxSize().safeHorizontalContentPadding(),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(stringResource(R.string.ge_empty), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> LazyColumn(
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = 8.dp + headerInset,
                        bottom = 24.dp + LocalMiniPlayerScrollClearance.current + safeDrawingBottomPadding(),
                    ),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize().safeHorizontalContentPadding(),
                ) {
                    items(state.stats, key = { it.name }) { stat ->
                        GenreBarRow(
                            name = stat.name,
                            percent = stat.percentOfTop,
                            onClick = { viewModel.openDetail(stat.name) },
                            modifier = Modifier.animateItem(),
                        )
                    }
                }
            }
        }
        }
    }

    state.detailGenre?.let { genre ->
        GenreDetailSheet(
            genre = genre,
            state = state,
            onDismiss = viewModel::closeDetail,
            onLoadMore = { viewModel.loadDetailPage() },
            onStartMix = { viewModel.startMix(genre) },
            onDiscoverMore = { viewModel.discoverMore(genre) },
            onShowYourTracks = viewModel::showYourTracks,
            onExploreGenre = { viewModel.exploreGenre(it) },
        )
    }
}


@Composable
private fun PeriodDropdown(period: String, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    val label = GENRE_PERIODS.firstOrNull { it.first == period }?.second ?: "Overall"
    Box {
        Surface(
            shape = RoundedCornerShape(50),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.clickable { expanded = true },
        ) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(label, style = MaterialTheme.typography.labelLarge)
            }
        }
        androidx.compose.material3.DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            GENRE_PERIODS.forEach { (value, text) ->
                androidx.compose.material3.DropdownMenuItem(text = { Text(text) }, onClick = { onChange(value); expanded = false })
            }
        }
    }
}

@Composable
private fun GenreBarRow(
    name: String,
    percent: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val animated by animateFloatAsState(targetValue = percent.coerceIn(0.03f, 1f), animationSpec = tween(600), label = "genreBar")
    Column(modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(name.replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text("${(percent * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surfaceContainerHighest)) {
            Box(
                Modifier
                    .fillMaxWidth(animated)
                    .height(10.dp)
                    .clip(RoundedCornerShape(50))
                    .background(MaterialTheme.colorScheme.primary),
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GenreDetailSheet(
    genre: String,
    state: GenresUiState,
    onDismiss: () -> Unit,
    onLoadMore: () -> Unit,
    onStartMix: () -> Unit,
    onDiscoverMore: () -> Unit,
    onShowYourTracks: () -> Unit,
    onExploreGenre: (String) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState()
    var menuTrack by remember { mutableStateOf<GeneratedTrack?>(null) }
    val listState = rememberLazyListState()

    val shouldLoadMore by remember(listState, state.detailTracks.size) {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            last >= state.detailTracks.size - 5
        }
    }
    LaunchedEffect(shouldLoadMore, state.detailTracks.size, state.detailLoading, state.detailHasMore, state.isDiscoverMode) {
        if (shouldLoadMore && !state.detailLoading && state.detailHasMore && !state.isDiscoverMode) onLoadMore()
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            Modifier
                .fillMaxSize()
                .adaptiveContentWidth(maxWidth = 640.dp)
                .align(Alignment.CenterHorizontally),
        ) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
                Text(genre.replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    if (state.isDiscoverMode) "Discoveries \u2022 Fresh recommendations" else "Your Tracks \u2022 Based on your scrobbles",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                androidx.compose.material3.Button(onClick = onStartMix, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.fr_start_mix))
                }
                if (state.isDiscoverMode) {
                    androidx.compose.material3.OutlinedButton(onClick = onShowYourTracks, modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.ge_tracks))
                    }
                } else {
                    androidx.compose.material3.OutlinedButton(onClick = onDiscoverMore, modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.ge_discover))
                    }
                }
            }

            LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(bottom = 12.dp)) {
                itemsIndexed(state.detailTracks, key = { index, track -> "${track.key}_$index" }) { _, track ->
                    GenreTrackRow(
                        track = track,
                        allTracks = state.detailTracks,
                        genreTitle = "${genre.replaceFirstChar { it.uppercase() }}",
                        onMenu = { menuTrack = track },
                        modifier = Modifier.animateItem(),
                    )
                }
                if (state.detailLoading) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            com.lastwave.app.ui.common.ExpressiveInlineLoadingIndicator()
                        }
                    }
                }
                if (!state.detailLoading && state.detailTracks.isEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text(stringResource(R.string.ge_no_tracks), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    menuTrack?.let { track ->
        TrackContextMenuSheet(
            target = TrackMenuTarget.Track(track.name, track.artist, track.url),
            capabilities = TrackMenuCapabilities(showDeleteScrobble = true),
            playbackSourceLabel = "Genres",
            onDismiss = { menuTrack = null },
            onExploreGenre = onExploreGenre,
        )
    }
}

@Composable
private fun GenreTrackRow(
    track: GeneratedTrack,
    allTracks: List<GeneratedTrack>,
    genreTitle: String,
    onMenu: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val musicPlayer = com.lastwave.app.ui.player.LocalMusicPlayer.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable {
                val queue = allTracks.map {
                    com.lastwave.app.playback.PlayableTrack(it.name, it.artist, album = it.album, artworkUrl = it.artworkUrl)
                }
                val index = allTracks.indexOf(track).coerceAtLeast(0)
                musicPlayer.playQueue(queue, startIndex = index, sourceLabel = genreTitle)
            }
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ArtworkImage(name = track.name, artist = track.artist, embeddedUrl = track.artworkUrl, fallbackIcon = Icons.Filled.MusicNote, modifier = Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(track.artist, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        com.lastwave.app.ui.common.OverflowMenuButton(onClick = onMenu)
    }
}
