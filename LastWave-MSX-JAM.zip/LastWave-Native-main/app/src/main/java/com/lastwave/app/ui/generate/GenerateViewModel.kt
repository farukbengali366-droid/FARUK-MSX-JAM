package com.lastwave.app.ui.generate

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lastwave.app.data.generate.GenerateRepository
import com.lastwave.app.data.generate.GeneratedTrack
import com.lastwave.app.data.generate.GenerationStatus
import com.lastwave.app.data.generate.RECOMMENDATION_TRACK_COUNT
import com.lastwave.app.data.generate.youtubeVideoIdOrNull
import com.lastwave.app.data.naming.PlaylistNamer
import com.lastwave.app.data.playlist.PlaylistRepository
import com.lastwave.app.playback.toPlayableTrack
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import javax.inject.Inject

private const val GENERATION_TIMEOUT_MS = 60_000L

/** Generator modes. YouTube Music is the primary engine; Last.fm only fills
 *  gaps when connected, and guest/offline falls back to local + charts. */
enum class GenerateMode(val labelRes: Int, val descriptionRes: Int, val storageValue: String) {
    TOP(com.lastwave.app.R.string.gen_mode_top, com.lastwave.app.R.string.gen_mode_top_desc, "top"),
    RECENT(com.lastwave.app.R.string.gen_mode_recent, com.lastwave.app.R.string.gen_mode_recent_desc, "recent"),
    SIMILAR_TRACKS(com.lastwave.app.R.string.gen_mode_song_radio, com.lastwave.app.R.string.gen_mode_song_radio_desc, "similar-tracks"),
    SIMILAR_ARTISTS(com.lastwave.app.R.string.gen_mode_sim_artists, com.lastwave.app.R.string.gen_mode_sim_artists_desc, "similar-artists"),
    TAG(com.lastwave.app.R.string.gen_mode_tag, com.lastwave.app.R.string.gen_mode_tag_desc, "tag"),
    MIX(com.lastwave.app.R.string.gen_mode_mix, com.lastwave.app.R.string.gen_mode_mix_desc, "mix"),
    RECOMMENDATIONS(com.lastwave.app.R.string.gen_mode_reco, com.lastwave.app.R.string.gen_mode_reco_desc, "recommendations"),
    NEVER_HEARD(com.lastwave.app.R.string.gen_mode_never, com.lastwave.app.R.string.gen_mode_never_desc, "never-heard"),
    LIBRARY(com.lastwave.app.R.string.gen_mode_library, com.lastwave.app.R.string.gen_mode_library_desc, "library"),
}

/** Exact 6 period chips shared by Top Tracks + My Library. */
val GENERATE_PERIODS = listOf(
    "overall" to com.lastwave.app.R.string.gen_period_all,
    "12month" to com.lastwave.app.R.string.gen_period_12mo,
    "6month" to com.lastwave.app.R.string.gen_period_6mo,
    "3month" to com.lastwave.app.R.string.gen_period_3mo,
    "1month" to com.lastwave.app.R.string.gen_period_1mo,
    "7day" to com.lastwave.app.R.string.gen_period_7d,
)

/** Exact 12 quick-select genre chips from generator.html's tag-suggestions. */
val GENRE_QUICK_CHIPS = listOf("pop", "rock", "hip-hop", "electronic", "jazz", "lofi", "metal", "indie", "classical", "r&b", "ambient", "punk")

@Immutable
data class GenerateUiState(
    val selectedMode: GenerateMode? = null,
    val trackCount: Int = 25,
    val period: String = "overall",
    val seedTrackName: String = "",
    val seedArtistName: String = "",
    val seedVideoId: String? = null,
    val seedArtistQuery: String = "",
    val tagInput: String = "",
    val seedTrackResults: List<GeneratedTrack> = emptyList(),
    val seedArtistResults: List<String> = emptyList(),
    val isSearchingSeed: Boolean = false,
    val isGenerating: Boolean = false,
    val loadingMessage: String = "",
    val error: String? = null,
)

/** One-shot navigation signal. */
sealed interface GenerateNavEvent {
    data class NavigateToPlaylistLoading(val playlistId: Long? = null) : GenerateNavEvent
}

@HiltViewModel
class GenerateViewModel @Inject constructor(
    private val repository: GenerateRepository,
    private val playlistRepository: PlaylistRepository,
    private val artworkRepository: com.lastwave.app.data.artwork.ArtworkRepository,
    private val generationStatus: GenerationStatus,
    private val mixLauncher: MixLauncher,
    private val musicPlayer: com.lastwave.app.playback.MusicPlayer,
) : ViewModel() {

    /** Set by a "Start Mix" launch: the generated mix also becomes the queue. */
    private var queueNextResult = false

    private val _uiState = MutableStateFlow(GenerateUiState())
    val uiState: StateFlow<GenerateUiState> = _uiState.asStateFlow()

    private val _navEvents = MutableSharedFlow<GenerateNavEvent>(extraBufferCapacity = 1)
    val navEvents: SharedFlow<GenerateNavEvent> = _navEvents

    val lastSavedPlaylistId = MutableStateFlow<Long?>(null)
    private var seedSearchJob: Job? = null

    init {
        // "Start Mix with this Song" landing here from any screen's
        // track menu: pre-fill Similar Tracks with the tapped song and
        // generate immediately — a real one-tap mix.
        viewModelScope.launch {
            mixLauncher.pendingSeed.collect { seed ->
                if (seed != null) {
                    val consumed = mixLauncher.consume() ?: seed
                    clearSeedSearch()
                    _uiState.update {
                        it.copy(
                            selectedMode = GenerateMode.SIMILAR_TRACKS,
                            seedTrackName = consumed.trackName,
                            seedArtistName = consumed.artistName,
                            seedVideoId = consumed.videoId,
                            trackCount = 28,
                            error = null,
                        )
                    }
                    queueNextResult = true
                    generate()
                }
            }
        }
    }

    private fun clearSeedSearch() {
        seedSearchJob?.cancel()
        seedSearchJob = null
        _uiState.update {
            it.copy(isSearchingSeed = false, seedTrackResults = emptyList(), seedArtistResults = emptyList())
        }
    }

    fun selectMode(mode: GenerateMode) {
        if (_uiState.value.isGenerating) return
        clearSeedSearch()
        _uiState.update {
            it.copy(selectedMode = if (it.selectedMode == mode) null else mode, error = null)
        }
    }

    fun setTrackCount(value: Int) { if (!_uiState.value.isGenerating) _uiState.update { it.copy(trackCount = value.coerceIn(5, 35)) } }
    fun setPeriod(value: String) = _uiState.update { it.copy(period = value) }
    fun setTagInput(value: String) = _uiState.update { it.copy(tagInput = value) }
    fun setSeedArtistQuery(value: String) {
        clearSeedSearch()
        _uiState.update { it.copy(seedArtistQuery = value) }
    }
    fun setSeedTrackName(value: String) {
        clearSeedSearch()
        _uiState.update { it.copy(seedTrackName = value, seedVideoId = null) }
    }
    fun setSeedArtistName(value: String) {
        clearSeedSearch()
        _uiState.update { it.copy(seedArtistName = value, seedVideoId = null) }
    }

    private fun <T> loadSeedResults(load: suspend () -> T, apply: (GenerateUiState, T) -> GenerateUiState) {
        clearSeedSearch()
        _uiState.update { it.copy(isSearchingSeed = true, error = null) }
        seedSearchJob = viewModelScope.launch {
            try {
                val results = load()
                // A cancelled provider may still return; never publish into an edited seed or another mode.
                coroutineContext.ensureActive()
                _uiState.update { apply(it, results).copy(isSearchingSeed = false) }
            } catch (e: Exception) {
                coroutineContext.ensureActive()
                _uiState.update { it.copy(isSearchingSeed = false, error = e.message) }
            }
        }
    }

    fun loadTopTracksForSeed() = loadSeedResults(
        load = { repository.topTracksForSeed() },
        apply = { state, results -> state.copy(seedTrackResults = results) },
    )

    fun loadTopArtistsForSeed() = loadSeedResults(
        load = { repository.topArtistsForSeed() },
        apply = { state, results -> state.copy(seedArtistResults = results) },
    )

    fun searchSeedTrack() {
        val state = _uiState.value
        if (state.seedTrackName.isBlank()) return
        loadSeedResults(
            load = { repository.searchTracks(state.seedTrackName, state.seedArtistName.ifBlank { null }) },
            apply = { current, results -> current.copy(seedTrackResults = results) },
        )
    }

    fun searchSeedArtist() {
        val state = _uiState.value
        if (state.seedArtistQuery.isBlank()) return
        loadSeedResults(
            load = { repository.searchArtists(state.seedArtistQuery) },
            apply = { current, results -> current.copy(seedArtistResults = results) },
        )
    }

    fun pickSeedTrack(track: GeneratedTrack) {
        clearSeedSearch()
        _uiState.update {
            it.copy(seedTrackName = track.name, seedArtistName = track.artist, seedVideoId = track.youtubeVideoIdOrNull())
        }
    }
    fun pickSeedArtist(name: String) {
        clearSeedSearch()
        _uiState.update { it.copy(seedArtistQuery = name) }
    }
    fun setGenreChip(tag: String) = _uiState.update { it.copy(tagInput = tag) }

    fun dismissError() = _uiState.update { it.copy(error = null) }

    fun generate() {
        // Taken first, so a launch that fails validation or is refused here
        // can never make a later manual generate re-queue.
        val queueMix = queueNextResult
        queueNextResult = false
        val state = _uiState.value
        if (state.isGenerating) return
        val mode = state.selectedMode ?: return

        when (mode) {
            GenerateMode.SIMILAR_TRACKS -> if (state.seedTrackName.isBlank() || state.seedArtistName.isBlank()) {
                _uiState.update { it.copy(error = "Enter a seed track and artist") }; return
            }
            GenerateMode.SIMILAR_ARTISTS -> if (state.seedArtistQuery.isBlank()) {
                _uiState.update { it.copy(error = "Enter a seed artist") }; return
            }
            GenerateMode.TAG -> if (state.tagInput.isBlank()) {
                _uiState.update { it.copy(error = "Enter a genre/tag") }; return
            }
            else -> Unit
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isGenerating = true, error = null, loadingMessage = "Analyzing taste profile\u2026") }
            generationStatus.update(isGenerating = true, message = "Analyzing taste profile\u2026")
            try {
                val onProgress: (String) -> Unit = { msg ->
                    _uiState.update { s -> s.copy(loadingMessage = msg) }
                    generationStatus.update(isGenerating = true, message = msg)
                }

                if (mode == GenerateMode.SIMILAR_TRACKS) {
                    onProgress("Finding similar songs with YouTube Music\u2026")
                } else {
                    onProgress("Blending Last.fm and YouTube Music\u2026")
                }

                val targetCount = if (mode == GenerateMode.RECOMMENDATIONS) {
                    RECOMMENDATION_TRACK_COUNT
                } else {
                    state.trackCount
                }
                // Pull a wider ranked pool so saved songs can be softly
                // deprioritized without shrinking the requested playlist.
                val candidateCount = if (mode == GenerateMode.RECOMMENDATIONS) {
                    targetCount
                } else {
                    (targetCount + maxOf(10, targetCount / 2)).coerceAtMost(60)
                }

                val raw: List<GeneratedTrack> = withTimeout(GENERATION_TIMEOUT_MS) {
                    when (mode) {
                        GenerateMode.TOP -> repository.fetchTopTracks(candidateCount, state.period)
                        GenerateMode.LIBRARY -> repository.fetchTopTracks(candidateCount, state.period)
                        GenerateMode.RECENT -> repository.fetchRecentTracks(candidateCount)
                        GenerateMode.SIMILAR_TRACKS -> repository.fetchSimilarTracks(
                            track = state.seedTrackName,
                            artist = state.seedArtistName,
                            limit = candidateCount,
                            seedVideoId = state.seedVideoId,
                        )
                        GenerateMode.SIMILAR_ARTISTS -> repository.fetchSimilarArtistTracks(state.seedArtistQuery, candidateCount)
                        GenerateMode.TAG -> repository.fetchTagTracks(state.tagInput, candidateCount)
                        GenerateMode.MIX -> repository.fetchMix(candidateCount, onProgress)
                        GenerateMode.RECOMMENDATIONS -> repository.fetchRecommendations(targetCount, onProgress)
                        GenerateMode.NEVER_HEARD -> repository.fetchNeverHeardTracks(candidateCount, onProgress)
                    }
                }

                onProgress("Pre-checking availability\u2026")
                val preparedTracks = if (mode == GenerateMode.RECOMMENDATIONS) {
                    // RecommendationEngine already applies its own diversity
                    // stages. Do not discard fresh tracks afterward via the
                    // generic per-artist cap and accidentally save under 35.
                    repository.deduplicate(raw)
                } else {
                    repository.precheck(raw)
                }
                val finalTracks = if (mode == GenerateMode.NEVER_HEARD) {
                    preparedTracks.take(targetCount)
                } else {
                    repository.preferPlaylistFreshness(
                        tracks = preparedTracks,
                        limit = targetCount,
                        savedKeys = repository.savedPlaylistTrackKeys(),
                    )
                }
                if (finalTracks.isEmpty()) {
                    val message = if (mode == GenerateMode.SIMILAR_TRACKS && state.seedTrackName.isNotBlank()) {
                        "No similar songs found to mix for \"${state.seedTrackName}\"."
                    } else if (mode == GenerateMode.SIMILAR_ARTISTS && state.seedArtistQuery.isNotBlank()) {
                        "No similar artists found for \"${state.seedArtistQuery}\"."
                    } else if (mode == GenerateMode.TAG && state.tagInput.isNotBlank()) {
                        "No songs found for tag \"${state.tagInput}\"."
                    } else {
                        "No songs found to create this mix."
                    }
                    throw IllegalStateException(message)
                }

                onProgress("Saving playlist\u2026")
                val existingTitles = playlistRepository.titles()
                val title = PlaylistNamer.generateUniqueName(existingTitles)
                val subtitle = PlaylistNamer.subtitleFor(
                    mode = mode.storageValue,
                    tagInput = state.tagInput,
                    seedTrackName = state.seedTrackName,
                    seedArtistInput = state.seedArtistQuery,
                )
                val saved = playlistRepository.save(title, subtitle, mode.storageValue, finalTracks)
                lastSavedPlaylistId.value = saved.id
                // Start Mix: the playing song stays, the mix takes over the queue after it.
                if (queueMix) musicPlayer.replaceUpcoming(finalTracks.map { it.toPlayableTrack() })

                // Playlist is persisted — done from the user's point of view.
                // Cover-art enrichment keeps running in the background and
                // updates rows reactively via ArtworkRepository's own flow,
                // so we don't make the user wait on it before showing the result.
                viewModelScope.launch {
                    try {
                        artworkRepository.enrichBatch(finalTracks.take(8).map { it.name to it.artist })
                    } catch (e: Exception) { }
                }

                _navEvents.tryEmit(GenerateNavEvent.NavigateToPlaylistLoading(saved.id))
            } catch (_: TimeoutCancellationException) {
                _uiState.update { it.copy(error = "Playlist generation timed out. Check your connection and try again.") }
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (e: Exception) {
                _uiState.update { it.copy(error = e.message ?: "Couldn't generate a playlist") }
            } finally {
                _uiState.update { it.copy(isGenerating = false) }
                generationStatus.update(isGenerating = false)
            }
        }
    }
}
