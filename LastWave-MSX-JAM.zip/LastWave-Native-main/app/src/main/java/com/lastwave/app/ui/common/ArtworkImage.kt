package com.lastwave.app.ui.common

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.imageLoader
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.transform.Transformation
import com.lastwave.app.data.artwork.ArtworkNormalizer
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Faithful port of home.js's art-loading behavior for a single row:
 *  - If the track already carries a real (non-placeholder) Last.fm image,
 *    show it directly — zero network calls, matching `!t.image` gating in
 *    enrichTracksWithArt()/​_enrichHomeArt().
 *  - Otherwise, request resolution (Last.fm track.getInfo -> iTunes) the
 *    moment this row enters composition, and recompose automatically the
 *    instant the shared resolved-map StateFlow reports a result — whether
 *    that's this frame or several seconds later.
 *  - Only shows the fallback icon once every provider has genuinely
 *    reported no art (resolved value == ""); shows nothing but the
 *    caller's own background while still resolving.
 */
@Composable
fun ArtworkImage(
    name: String,
    artist: String,
    embeddedUrl: String?,
    fallbackIcon: ImageVector,
    modifier: Modifier = Modifier,
    decodeSizePx: Int? = null,
    alignment: Alignment = Alignment.Center,
    transformations: List<Transformation> = emptyList(),
    artworkViewModel: ArtworkViewModel = LocalArtworkViewModel.current ?: hiltViewModel(),
) {
    val context = LocalContext.current
    val key = remember(name, artist) { ArtworkNormalizer.cacheKey(name, artist) }
    // Collect ONLY this row's slot of the shared resolved-map. Collecting the
    // whole map meant every resolution anywhere recomposed every visible
    // artwork row; with distinctUntilChanged each row recomposes exactly once —
    // when its own URL resolves.
    val resolvedUrl by remember(key) {
        artworkViewModel.resolved.map { it[key] }.distinctUntilChanged()
    }.collectAsStateWithLifecycle(initialValue = artworkViewModel.resolved.value[key])
    val isCellular = LocalArtworkCellular.current ?: artworkViewModel.isCellular.collectAsStateWithLifecycle().value
    var resolvedFailed by remember(key, resolvedUrl) { mutableStateOf(false) }
    var embeddedFailed by remember(name, artist, embeddedUrl) { mutableStateOf(false) }
    var refreshRequested by remember(key) { mutableStateOf(false) }
    var lastSuccessfulPainter by remember(key) { mutableStateOf<Painter?>(null) }

    // Local songs: a cover extracted from the user's own file wins
    // over any online lookup, and no lookup is started for it.
    val localCover = embeddedUrl?.startsWith("file://") == true && !embeddedFailed

    LaunchedEffect(key, resolvedFailed, localCover) {
        if (localCover) return@LaunchedEffect
        if (resolvedFailed && !refreshRequested) {
            refreshRequested = true
            artworkViewModel.refresh(name, artist)
        } else if (resolvedUrl == null) {
            artworkViewModel.resolve(name, artist)
        }
    }

    val highResUrl = resolvedUrl?.takeIf { it.isNotBlank() }
    val useHighRes = highResUrl != null && !resolvedFailed

    // High-resolution master artwork from Spotify -> Apple Music -> Tidal -> Deezer takes priority.
    // While resolving in background, embeddedUrl (upscaled) is shown seamlessly.
    val displayUrl = if (localCover) {
        embeddedUrl
    } else if (useHighRes) {
        highResUrl
    } else if (ArtworkNormalizer.isRealImage(embeddedUrl) && !embeddedFailed) {
        ArtworkNormalizer.upscaleYoutubeArtwork(embeddedUrl)
    } else {
        null
    }

    val mobileDataUrl = remember(displayUrl, embeddedUrl, localCover) {
        if (localCover) null else ArtworkNormalizer.mobileDataArtwork(displayUrl, embeddedUrl)
    }
    var highResCacheHit by remember(displayUrl, mobileDataUrl, isCellular, decodeSizePx, transformations) {
        mutableStateOf<Boolean?>(null)
    }
    val useMobileVariant = isCellular && !localCover &&
        !displayUrl.isNullOrBlank() && !mobileDataUrl.isNullOrBlank() && mobileDataUrl != displayUrl
    LaunchedEffect(displayUrl, mobileDataUrl, isCellular, localCover, context) {
        val cachedUrl = displayUrl
        if (!useMobileVariant || cachedUrl.isNullOrBlank()) {
            highResCacheHit = null
            return@LaunchedEffect
        }
        val snapshot = withContext(Dispatchers.IO) {
            context.imageLoader.diskCache?.openSnapshot(cachedUrl)
        }
        highResCacheHit = snapshot != null
        snapshot?.close()
    }
    val requestUrl = when {
        useMobileVariant && highResCacheHit == null -> null
        useMobileVariant && highResCacheHit == true -> displayUrl
        useMobileVariant -> mobileDataUrl
        else -> displayUrl
    }

    val retainedPainter = lastSuccessfulPainter
    Box(modifier = modifier, contentAlignment = alignment) {
        if (!requestUrl.isNullOrBlank()) {
            val model = remember(requestUrl, decodeSizePx, transformations, context) {
                val builder = ImageRequest.Builder(context)
                    .data(requestUrl)
                    .diskCacheKey(requestUrl)
                    .crossfade(300)
                if (decodeSizePx != null) builder.size(decodeSizePx)
                if (transformations.isNotEmpty()) builder.transformations(transformations)
                builder.build()
            }
            AsyncImage(
                model = model,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alignment = alignment,
                placeholder = retainedPainter,
                error = retainedPainter,
                onSuccess = {
                    lastSuccessfulPainter = it.painter
                },
                modifier = Modifier.fillMaxSize(),
                onError = {
                    if (localCover) {
                        embeddedFailed = true
                    } else if (requestUrl == displayUrl && useHighRes) {
                        resolvedFailed = true
                    } else {
                        embeddedFailed = true
                    }
                },
            )
        } else if (retainedPainter != null) {
            Image(
                painter = retainedPainter,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alignment = alignment,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Icon(
                fallbackIcon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (resolvedUrl == null) 0.35f else 0.6f),
                modifier = Modifier.fillMaxSize(0.42f),
            )
        }
    }
}
