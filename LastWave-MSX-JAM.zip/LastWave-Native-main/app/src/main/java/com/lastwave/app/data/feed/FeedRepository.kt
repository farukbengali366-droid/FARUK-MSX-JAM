package com.lastwave.app.data.feed

import androidx.compose.runtime.Immutable
import com.lastwave.app.data.artwork.ArtworkNormalizer
import com.lastwave.app.util.ArtistHelper
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import com.lastwave.app.data.generate.GeneratedTrack
import com.lastwave.app.data.generate.youtubeVideoIdOrNull
import com.lastwave.app.data.model.ArtistRef
import com.lastwave.app.data.model.ImageDto
import com.lastwave.app.data.generate.TasteProfileProvider
import com.lastwave.app.data.model.FriendEntry
import com.lastwave.app.data.model.RecentTrack
import com.lastwave.app.data.music.InnerTubeMusicApi
import com.lastwave.app.data.music.HomeChip
import com.lastwave.app.data.music.HomePage
import com.lastwave.app.data.music.HomeShelf
import com.lastwave.app.data.music.HomeShelfItem
import com.lastwave.app.data.music.YouTubeMusicTrack
import com.lastwave.app.data.music.YouTubePlaylistSummary
import com.lastwave.app.data.podcast.PodcastRepository
import com.lastwave.app.data.podcast.PodcastShelf
import com.lastwave.app.data.podcast.PodcastShow
import com.lastwave.app.data.local.SettingsPreferences
import com.lastwave.app.data.playlist.PlaylistRepository
import com.lastwave.app.data.recommend.RecommendationRepository
import com.lastwave.app.data.repository.HomeRepository
import com.lastwave.app.data.ytmusic.YtConnection
import com.lastwave.app.data.ytmusic.YtMusicAuthManager
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import javax.inject.Inject
import javax.inject.Singleton

@Immutable
data class FeedQuickTile(
    val title: String,
    val subtitle: String? = null,
    val artworkUrl: String? = null,
    val actionVideoId: String? = null,
    val playlistId: String? = null,
    val localPlaylistId: Long? = null,
    val isLiked: Boolean = false,
    val collection: String? = null,
)

@Immutable
data class FeedMix(val title: String, val seed: YouTubeMusicTrack)

@Immutable
data class FeedSectionData<T>(
    val title: String,
    val subtitle: String? = null,
    val items: List<T>,
)

@Immutable
data class FeedArtist(
    val name: String,
    val browseId: String? = null,
    val artworkUrl: String? = null,
)

@Immutable
data class FeedAlbum(
    val title: String,
    val artist: String,
    val artworkUrl: String? = null,
    val browseId: String? = null,
)

@Immutable
data class FeedSpotlight(
    val artistName: String,
    val artworkUrl: String? = null,
    val browseId: String? = null,
    val description: String? = null,
    val topTrackTitle: String? = null,
    /** Further spotlight artists for the pager; empty means a single card. */
    val more: List<FeedSpotlight> = emptyList(),
)

@Immutable
data class FeedData(
    val isYtConnected: Boolean = false,
    val ytAccountName: String? = null,
    val userName: String? = null,
    val hasYtRecommendations: Boolean = false,
    val hasYtMixes: Boolean = false,
    val hasPersonalContent: Boolean = false,
    val tasteTags: List<String> = emptyList(),
    val nativeShelves: List<HomeShelf> = emptyList(),
    val homeChips: List<HomeChip> = emptyList(),
    val homeContinuationToken: String? = null,
    val ytSuggestedPlaylists: List<YouTubePlaylistSummary> = emptyList(),
    val spotlight: FeedSpotlight? = null,
    val quickTiles: List<FeedQuickTile> = emptyList(),
    val quickPicks: List<YouTubeMusicTrack> = emptyList(),
    val newReleases: List<YouTubePlaylistSummary> = emptyList(),
    val charts: List<YouTubeMusicTrack> = emptyList(),
    val mixes: List<FeedMix> = emptyList(),
    val jumpBackIn: List<RecentTrack> = emptyList(),
    val recentAlbums: List<FeedAlbum> = emptyList(),
    val topArtists: List<FeedArtist> = emptyList(),
    val heavyRotation: List<GeneratedTrack> = emptyList(),
    val ytLikedSongs: List<YouTubeMusicTrack> = emptyList(),
    val ytRecentSongs: List<YouTubeMusicTrack> = emptyList(),
    val becauseYouListenTo: FeedSectionData<YouTubeMusicTrack>? = null,
    val freshFinds: List<YouTubeMusicTrack> = emptyList(),
    val friends: List<FriendEntry> = emptyList(),
    val podcastShows: List<PodcastShow> = emptyList(),
    val podcastShelfTitle: String? = null,
    val lastUpdatedMillis: Long = 0L,
) {
    val hasContent: Boolean get() =
        nativeShelves.any { it.items.isNotEmpty() } ||
            quickTiles.isNotEmpty() || mixes.isNotEmpty() || topArtists.isNotEmpty() ||
            quickPicks.isNotEmpty() || jumpBackIn.isNotEmpty() || recentAlbums.isNotEmpty() ||
            heavyRotation.isNotEmpty() || ytLikedSongs.isNotEmpty() || ytRecentSongs.isNotEmpty() ||
            (becauseYouListenTo?.items?.isNotEmpty() == true) || freshFinds.isNotEmpty() ||
            spotlight != null || charts.isNotEmpty() || newReleases.isNotEmpty() || friends.isNotEmpty() ||
            podcastShows.isNotEmpty()
}

@Singleton
class FeedRepository @Inject constructor(
    private val innerTube: InnerTubeMusicApi,
    private val recommendationRepository: RecommendationRepository,
    private val homeRepository: HomeRepository,
    private val tasteProfileProvider: TasteProfileProvider,
    private val ytAuth: YtMusicAuthManager,
    private val playlistRepository: PlaylistRepository,
    private val podcastRepository: PodcastRepository,
    private val settingsPreferences: SettingsPreferences,
) {
    @Volatile private var cached: Pair<String, FeedData>? = null
    private val artistEntityCache = ConcurrentHashMap<String, FeedArtist>()

    fun getCachedFeed(): FeedData? = cached?.second

    fun getCachedFeed(username: String?, connection: YtConnection): FeedData? =
        cached?.takeIf { it.first.startsWith("${username.orEmpty()}|$connection|") }?.second

    suspend fun loadFeed(
        username: String?,
        onUpdate: (FeedData) -> Unit = {},
    ): FeedData = withContext(Dispatchers.Default) {
        val connectionPre = ytAuth.awaitLoadedConnection()
        val settingsSnapshot = settingsPreferences.settings.first()
        val podcastsEnabled = settingsSnapshot.podcastsEnabled
        val cacheKey = "${username.orEmpty()}|$connectionPre|podcasts=$podcastsEnabled|rec=${settingsSnapshot.recommendationSource.id}"
        val previous = cached?.takeIf { it.first == cacheKey }?.second
        val random = kotlin.random.Random(System.nanoTime())
        val connection = connectionPre
        val isYtConnected = connection.isConnected

        val newReleasesDef = async(Dispatchers.IO) { runCatching { innerTube.fetchNewReleases() }.getOrDefault(emptyList()) }
        val chartsDef = async(Dispatchers.IO) { runCatching { innerTube.fetchCharts() }.getOrDefault(emptyList()) }
        val homeMixesDef = async(Dispatchers.IO) { runCatching { innerTube.fetchHomeMixes() }.getOrDefault(emptyList()) }
        val homeSongsDef = async(Dispatchers.IO) {
            runCatching { innerTube.fetchHomeSongs() }.getOrDefault(emptyList())
        }
        val homePageDef = async(Dispatchers.IO) {
            runCatching { innerTube.fetchHomePage() }.getOrDefault(HomePage())
        }
        // Podcast shelf rides along with the rest of the feed. Loaded from
        // YouTube Music Podcasts chip page 1 ("Shows for you" shelf) with a random sample of ~10 shows.
        val podcastShelfDef = async(Dispatchers.IO) {
            if (!podcastsEnabled) return@async null
            runCatching {
                val homePage = homePageDef.await()
                val podcastChip = homePage.chips.firstOrNull { it.title.equals("Podcasts", ignoreCase = true) }
                    ?: HomeChip(title = "Podcasts", params = "ggMPOg1mZWVkX3BvZGNhc3Rz")
                val chipPage = innerTube.fetchHomeChip(podcastChip)
                val showsShelf = chipPage.shelves.firstOrNull { shelf ->
                    shelf.items.any { it is HomeShelfItem.PodcastShow }
                } ?: chipPage.shelves.firstOrNull()

                val rawShows = showsShelf?.items?.filterIsInstance<HomeShelfItem.PodcastShow>().orEmpty()
                if (rawShows.isEmpty()) null
                else {
                    val sampled = rawShows.shuffled(random).take(10).map { show ->
                        PodcastShow(
                            showId = show.browseId,
                            title = show.title,
                            publisher = show.author,
                            artworkUrl = show.artworkUrl,
                        )
                    }
                    val shelfTitle = showsShelf?.title?.takeIf { it.isNotBlank() } ?: "Popular shows"
                    PodcastShelf(
                        title = shelfTitle,
                        shows = sampled,
                    )
                }
            }.getOrNull()
        }

        val ytTasteDef = async(Dispatchers.IO) {
            if (isYtConnected) {
                runCatching { innerTube.fetchTasteSignals(recentLimit = 40, likedLimit = 40, feedLimit = 60) }.getOrNull()
            } else null
        }

        val recentTracksDef = async(Dispatchers.IO) {
            if (!username.isNullOrBlank()) {
                runCatching {
                    homeRepository.fetchRecentTracks(page = 1, limit = 30, username = username).getOrNull()?.tracks.orEmpty()
                }.getOrDefault(emptyList())
            } else emptyList()
        }
        val friendsDef = async(Dispatchers.IO) {
            if (!username.isNullOrBlank()) {
                runCatching {
                    homeRepository.fetchFriends(limit = 20).getOrNull().orEmpty()
                }.getOrDefault(emptyList())
            } else emptyList()
        }
        val tasteProfileDef = async(Dispatchers.IO) {
            runCatching { tasteProfileProvider.get() }.getOrNull()
        }
        val likedSongsIdDef = async(Dispatchers.IO) {
            runCatching { playlistRepository.ensureLikedSongs().id }.getOrNull()
        }
        // Local-first fallback for guest/disconnected: liked songs + saved
        // playlist tracks from Room (on-device history proxy). Never throws.
        val localLibraryDef = async(Dispatchers.IO) {
            runCatching {
                val liked = playlistRepository.getLikedSongs()?.tracks.orEmpty()
                val saved = playlistRepository.getAll().flatMap { it.tracks }
                (liked + saved).filter { it.name.isNotBlank() && it.artist.isNotBlank() }
                    .distinctBy { it.key }
            }.getOrDefault(emptyList())
        }
        // Real Last.fm albums for the taste â€” fetched up-front in parallel.
        // Never derive albums from per-track `album` strings here: those are
        // usually just the single name and open a whole different record.
        val lastFmTopAlbumsDef = async(Dispatchers.IO) {
            if (!username.isNullOrBlank()) {
                runCatching { homeRepository.fetchTopAlbums(limit = 20, username = username).getOrNull().orEmpty() }
                    .getOrDefault(emptyList())
            } else emptyList()
        }

        val homePage = homePageDef.await()
        if (homePage.shelves.any { it.items.isNotEmpty() }) {
            onUpdate((previous ?: FeedData()).copy(
                isYtConnected = isYtConnected,
                ytAccountName = connection.accountName.takeIf { isYtConnected },
                userName = username,
                nativeShelves = homePage.shelves,
                homeChips = homePage.chips.ifEmpty { previous?.homeChips.orEmpty() },
                homeContinuationToken = homePage.continuationToken ?: previous?.homeContinuationToken,
            ))
        }

        val releaseCandidates = newReleasesDef.await()
        val charts = chartsDef.await()
        val homePlaylists = homeMixesDef.await().filter {
            it.id.startsWith("PL") || it.id.startsWith("RD") || it.id.startsWith("OLAK") || it.id == "LM"
        }
        val homeSongs = homeSongsDef.await()
        val nativeShelves = homePage.shelves.ifEmpty {
            runCatching { innerTube.fetchHomeShelves() }.getOrDefault(emptyList())
        }
        val homeChips = homePage.chips
        val homeContinuationToken = homePage.continuationToken
        val recentTracks = recentTracksDef.await()
        val friends = friendsDef.await()
        val tasteProfile = tasteProfileDef.await()
        val ytTaste = ytTasteDef.await()
        val likedSongsId = likedSongsIdDef.await()

        val localLibrary = localLibraryDef.await()
        val localQuickPicks = localLibrary.map {
            YouTubeMusicTrack(it.youtubeVideoIdOrNull().orEmpty(), it.name, it.artist, it.album, it.artworkUrl)
        }

        // Connected: personal mixes + taste signals + related artists lead.
        // Guest/disconnected: local-first â€” liked + saved Room tracks plus
        // accountless public trending (homeSongs/charts). Account-only
        // shelves (ytLikedSongs) stay empty so the UI suppresses them.
        val ytLikedSongs = ytTaste?.likedTracks.orEmpty()
            .takeIf { isYtConnected } .orEmpty()
        val ytRecentSongs = ytTaste?.recentTracks.orEmpty()
            .takeIf { isYtConnected } .orEmpty()
        val ytQuickPicks = if (isYtConnected) {
            ytTaste?.feedTracks.orEmpty().ifEmpty { homeSongs }
        } else {
            // Guest: local liked + public trending, never account-only.
            localQuickPicks + homeSongs
        }

        val affinity = tasteProfile?.artistAffinity.orEmpty()
        val previousPickIds = previous?.quickPicks.orEmpty().mapTo(mutableSetOf()) { it.videoId }
        fun trackScore(t: YouTubeMusicTrack, index: Int, sourceBoost: Double): Double {
            val keys = ArtistHelper.splitArtists(t.artist).map { it.trim().lowercase() }.ifEmpty { listOf(t.artist.trim().lowercase()) }
            val aff = keys.maxOfOrNull { affinity[it] ?: 0.0 } ?: 0.0
            val hasVideo = t.videoId.isNotBlank()
            val hasArt = ArtworkNormalizer.isRealImage(t.artworkUrl)
            val positionDecay = 1.0 / (1.0 + index / 9.0)
            return aff * 60.0 + sourceBoost * 14.0 * positionDecay +
                (if (hasVideo) 10.0 else -6.0) + (if (hasArt) 4.0 else 0.0) - (if (t.videoId in previousPickIds) 30.0 else 0.0)
        }
        fun <T> diversify(
            items: List<T>,
            artistOf: (T) -> String,
            maxPerArtist: Int = 2,
        ): List<T> {
            val counts = mutableMapOf<String, Int>()
            val out = ArrayList<T>(items.size)
            val deferred = ArrayList<T>()
            for (item in items) {
                val key = ArtistHelper.splitArtists(artistOf(item)).firstOrNull()?.trim()?.lowercase()
                    ?: artistOf(item).trim().lowercase()
                if ((counts[key] ?: 0) < maxPerArtist) {
                    counts[key] = (counts[key] ?: 0) + 1
                    out.add(item)
                } else deferred.add(item)
            }
            // Second pass fills remaining slots so shelves never look short.
            for (item in deferred) {
                val key = ArtistHelper.splitArtists(artistOf(item)).firstOrNull()?.trim()?.lowercase()
                    ?: artistOf(item).trim().lowercase()
                if ((counts[key] ?: 0) < maxPerArtist + 1) {
                    counts[key] = (counts[key] ?: 0) + 1
                    out.add(item)
                }
            }
            return out
        }

        fun <T> blend(first: List<T>, second: List<T>): List<T> = buildList {
            repeat(maxOf(first.size, second.size)) { index ->
                first.getOrNull(index)?.let { add(it) }
                second.getOrNull(index)?.let { add(it) }
            }
        }

        val regularPicks = tasteProfile?.topTracksRaw.orEmpty().map {
            YouTubeMusicTrack(it.youtubeVideoIdOrNull().orEmpty(), it.name, it.artist, it.album, it.artworkUrl)
        }

        val spotifySeeds = recommendationRepository.isSpotifyActive()
        val discoverySeeds = (ytLikedSongs + ytRecentSongs + regularPicks + localQuickPicks)
            .filter { it.videoId.isNotBlank() }
            .shuffled(random)
            .distinctBy { ArtistHelper.primaryArtist(it.artist).lowercase() }
            .take(if (spotifySeeds) 1 else 3)
        val discoveryDef = async(Dispatchers.IO) {
            discoverySeeds.map { seed ->
                async {
                    try {
                        recommendationRepository.relatedFor(
                            seedVideoId = seed.videoId,
                            title = seed.title,
                            artist = seed.artist,
                            limit = 30,
                            durationSeconds = seed.durationSeconds,
                        )
                    } catch (_: Exception) {
                        ensureActive()
                        emptyList()
                    }
                }
            }.awaitAll()
        }

        val familiarCandidates = buildList {
            ytQuickPicks.forEachIndexed { i, t -> add(t to trackScore(t, i, 2.8)) }
            homeSongs.forEachIndexed { i, t -> add(t to trackScore(t, i, 2.2)) }
            charts.forEachIndexed { i, t -> add(t to trackScore(t, i, 2.0)) }
            ytLikedSongs.forEachIndexed { i, t -> add(t to trackScore(t, i, 1.8)) }
            regularPicks.forEachIndexed { i, t -> add(t to trackScore(t, i, 1.6)) }
            localQuickPicks.forEachIndexed { i, t -> add(t to trackScore(t, i, 1.5)) }
            ytRecentSongs.forEachIndexed { i, t -> add(t to trackScore(t, i, 1.2)) }
        }
            .distinctBy { (t, _) -> t.artist.trim().lowercase() to t.title.trim().lowercase() }
            .sortedByDescending { it.second }
            .map { it.first }

        fun shelf(quickPicks: List<YouTubeMusicTrack>): FeedData = (previous ?: FeedData()).copy(
            isYtConnected = isYtConnected,
            ytAccountName = connection.accountName.takeIf { isYtConnected },
            userName = username,
            hasYtRecommendations = ytTaste?.feedTracks?.isNotEmpty() == true,
            hasPersonalContent = tasteProfile?.hasPersonalSignals == true || ytLikedSongs.isNotEmpty() || ytRecentSongs.isNotEmpty(),
            nativeShelves = nativeShelves.ifEmpty { previous?.nativeShelves.orEmpty() },
            homeChips = homeChips.ifEmpty { previous?.homeChips.orEmpty() },
            homeContinuationToken = homeContinuationToken ?: previous?.homeContinuationToken,
            quickPicks = quickPicks,
            ytLikedSongs = ytLikedSongs,
            ytRecentSongs = ytRecentSongs,
        )

        // First paint: familiar-only picks. These need no network beyond the
        // parallel batch above, so a cold feed shows shelves immediately.
        // Blending discovery into Quick Picks must never gate this
        // emission — the related-songs round-trips (3 x up to 30 tracks) are
        // the slowest calls in the load, and waiting on them left the whole
        // feed blank for seconds on a cold start.
        val familiarQuickPicks = diversify(familiarCandidates, YouTubeMusicTrack::artist, maxPerArtist = 2)
            .take(18)
            .ifEmpty { charts }
            .distinctBy { it.artist.trim().lowercase() to it.title.trim().lowercase() }
            .take(15)
        onUpdate(shelf(familiarQuickPicks))

        // Discovery: blends fresh picks over the familiar ones once the
        // round-trips land, and feeds Fresh Finds / Mixes below. It overlaps
        // with the artist fetches that follow instead of blocking paint.
        val discoveryBatches = withTimeoutOrNull(3000L) { discoveryDef.await() } ?: run {
            discoveryDef.cancel()
            emptyList()
        }
        val discoveryResults = discoverySeeds.zip(
            if (discoveryBatches.size == discoverySeeds.size) discoveryBatches else List(discoverySeeds.size) { emptyList<YouTubeMusicTrack>() }
        )
        val discoveryTracks = discoveryBatches.flatten().distinctBy { it.videoId }

        val familiarVideoIds = (ytLikedSongs + ytRecentSongs + regularPicks + localQuickPicks + homeSongs).mapTo(mutableSetOf()) { it.videoId }
        val familiarKeys = (ytLikedSongs + ytRecentSongs + regularPicks + localQuickPicks + homeSongs).mapTo(mutableSetOf()) {
            it.artist.trim().lowercase() to it.title.trim().lowercase()
        }

        val newDiscoveryCandidates = discoveryTracks.filter { track ->
            track.videoId.isNotBlank() &&
                track.videoId !in familiarVideoIds &&
                (track.artist.trim().lowercase() to track.title.trim().lowercase()) !in familiarKeys
        }

        val newCandidates = newDiscoveryCandidates
            .mapIndexed { i, t -> t to trackScore(t, i, 2.8) }
            .distinctBy { (t, _) -> t.artist.trim().lowercase() to t.title.trim().lowercase() }
            .sortedByDescending { it.second }
            .map { it.first }

        val freshOrChart = (newCandidates + charts.filter { it.videoId !in familiarVideoIds })
            .distinctBy { it.videoId }
        val quickCandidates = blend(
            first = diversify(familiarCandidates, YouTubeMusicTrack::artist, maxPerArtist = 1),
            second = diversify(freshOrChart, YouTubeMusicTrack::artist, maxPerArtist = 1),
        )

        val quickPicks = diversify(quickCandidates, YouTubeMusicTrack::artist, maxPerArtist = 2)
            .take(18)
            .ifEmpty { charts }
            .distinctBy { it.artist.trim().lowercase() to it.title.trim().lowercase() }
            .take(15)

        onUpdate(shelf(quickPicks))

        val knownArtists = buildSet {
            addAll(affinity.keys)
            addAll((ytLikedSongs + ytRecentSongs).flatMap { ArtistHelper.splitArtists(it.artist) }.map { it.trim().lowercase() })
            addAll(recentTracks.flatMap { ArtistHelper.splitArtists(it.artist.displayName) }.map { it.trim().lowercase() })
        }

        val artistSignalTracks = ytRecentSongs + ytLikedSongs + ytQuickPicks + homeSongs + charts
        val ytArtistNames = (ytRecentSongs + ytLikedSongs + if (isYtConnected) ytQuickPicks else emptyList())
            .flatMap { ArtistHelper.splitArtists(it.artist) }
            .filter { it.isNotBlank() && !it.equals("Unknown artist", ignoreCase = true) }
            .groupBy { it.trim().lowercase() }
            .values.sortedByDescending { it.size }
            .map { it.first().trim() }
        val listeningArtists = tasteProfile?.topArtistsRaw.orEmpty().flatMap(ArtistHelper::splitArtists)
        val tasteArtists = (blend(ytArtistNames, listeningArtists) +
            recentTracks.flatMap { ArtistHelper.splitArtists(it.artist.displayName) } +
            regularPicks.flatMap { ArtistHelper.splitArtists(it.artist) })
            .filter { it.isNotBlank() && !it.equals("Unknown artist", ignoreCase = true) }
            .map { it.lowercase() }.distinct()
        val artistRanks = tasteArtists.withIndex().associate { it.value to it.index }
        val matchedReleases = if (artistRanks.isEmpty()) releaseCandidates else releaseCandidates
            .mapNotNull { release ->
                val rank = ArtistHelper.splitArtists(release.author).mapNotNull { artistRanks[it.lowercase()] }.minOrNull()
                rank?.let { release to it }
            }.sortedBy { it.second }.map { it.first }.distinctBy { it.id }.take(15)
        val topArtistNames = buildList {
            repeat(maxOf(ytArtistNames.size, listeningArtists.size).coerceAtMost(8)) { index ->
                ytArtistNames.getOrNull(index)?.let { add(it) }
                listeningArtists.getOrNull(index)?.let { add(it) }
            }
            addAll(recentTracks.map { it.artist.displayName })
            if (isEmpty()) addAll(artistSignalTracks.map(YouTubeMusicTrack::artist))
        }
            .flatMap(ArtistHelper::splitArtists)
            .filter { it.isNotBlank() && !it.equals("Unknown artist", ignoreCase = true) }
            .distinctBy { it.lowercase() }
            .take(8)
            .shuffled(random)

        val topArtists = topArtistNames.map { name ->
            async(Dispatchers.IO) {
                val cached = artistEntityCache[name.lowercase()]
                if (cached != null) return@async cached
                val trackArtwork = artistSignalTracks
                    .firstOrNull { ArtistHelper.splitArtists(it.artist).any { artist -> artist.equals(name, ignoreCase = true) } }
                    ?.artworkUrl
                previous?.topArtists?.firstOrNull { it.name.equals(name, ignoreCase = true) && it.browseId != null }
                    ?.let {
                        artistEntityCache[name.lowercase()] = it
                        return@async it
                    }
                val entity = runCatching {
                    innerTube.searchArtists(name, limit = 3)
                        .firstOrNull { it.name.trim().equals(name, ignoreCase = true) }
                }.getOrNull()
                val feedArtist = FeedArtist(
                    name = name,
                    browseId = entity?.browseId,
                    artworkUrl = entity?.artworkUrl?.takeIf(ArtworkNormalizer::isRealImage) ?: trackArtwork,
                )
                artistEntityCache[name.lowercase()] = feedArtist
                feedArtist
            }
        }.awaitAll()

        val newReleases = (matchedReleases.ifEmpty { releaseCandidates })
            .distinctBy { it.id }.take(15)

        val familiarIds = (ytLikedSongs + ytRecentSongs + regularPicks).mapTo(mutableSetOf()) { it.videoId }
        val freshPool = (discoveryTracks + charts + homeSongs + ytQuickPicks)
            .filter { it.videoId.isNotBlank() && it.videoId !in familiarIds }
            .distinctBy { it.videoId }.shuffled(random)
        val previousFreshIds = previous?.freshFinds.orEmpty().mapTo(mutableSetOf()) { it.videoId }
        val freshFinds = diversify(
            freshPool.sortedWith(compareBy<YouTubeMusicTrack> { it.videoId in previousFreshIds }
                .thenBy { track -> ArtistHelper.splitArtists(track.artist).any { it.trim().lowercase() in knownArtists } }),
            YouTubeMusicTrack::artist,
            maxPerArtist = 1,
        ).take(12)
        val previousMixIds = previous?.mixes.orEmpty().mapTo(mutableSetOf()) { it.seed.videoId }
        val mixes = (quickPicks + ytLikedSongs + discoveryTracks)
            .filter { it.videoId.isNotBlank() }.distinctBy { it.videoId }.shuffled(random)
            .sortedBy { it.videoId in previousMixIds }
            .distinctBy { ArtistHelper.primaryArtist(it.artist).trim().lowercase() }.take(8)
            .map { FeedMix(title = "${ArtistHelper.primaryArtist(it.artist)} mix", seed = it) }

        // Heavy rotation: connected blends long-term taste + liked signals;
        // guest/disconnected builds it from local Room listening history
        // (liked + saved) so "Heavy Rotation" never empties.
        // Taste-weighted rotation: affinity dominates (40/35-point arms), but a
        // ±20 jitter reorders within taste bands and last load's picks sink 20,
        // so Heavy Rotation feels fresh every load without going generic.
        // Mirrors quickPicks' trackScore jitter/previous-penalty pattern.
        val previousHeavyKeys = previous?.heavyRotation.orEmpty().mapTo(mutableSetOf()) { it.key }
        fun rotationJitter(t: GeneratedTrack): Double =
            random.nextDouble() * 20.0 - (if (t.key in previousHeavyKeys) 20.0 else 0.0)
        val heavyCandidates = buildList {
            tasteProfile?.topTracksRaw?.forEachIndexed { i, t ->
                val aff = ArtistHelper.splitArtists(t.artist).maxOfOrNull { affinity[it.trim().lowercase()] ?: 0.0 } ?: 0.0
                add(t to (aff * 40 + 20.0 / (1 + i / 6.0) + rotationJitter(t)))
            }
            blend(ytRecentSongs, ytLikedSongs)
                .distinctBy { it.artist.trim().lowercase() to it.title.trim().lowercase() }
                .forEachIndexed { i, it ->
                    val generated = GeneratedTrack(
                        it.title, it.artist, it.artworkUrl,
                        url = "https://www.youtube.com/watch?v=${it.videoId}", album = it.album,
                    )
                    add(
                        generated to (12.0 / (1 + i / 6.0) + (affinity[ArtistHelper.primaryArtist(it.artist).trim().lowercase()] ?: 0.0) * 30 + rotationJitter(generated)),
                    )
                }
            // Local-first: Room liked + saved rank by affinity like taste.
            localLibrary.forEachIndexed { i, t ->
                val aff = ArtistHelper.splitArtists(t.artist).maxOfOrNull { affinity[it.trim().lowercase()] ?: 0.0 } ?: 0.0
                add(t to (aff * 35 + 16.0 / (1 + i / 6.0) + rotationJitter(t)))
            }
        }.distinctBy { (t, _) -> t.key }
            .sortedByDescending { it.second }
            .map { it.first }
        val heavyRotation = heavyCandidates.distinctBy(GeneratedTrack::key).take(15)
            .ifEmpty { localLibrary.take(15) }

        // Preserve each provider's history order while sharing the existing shelf.
        val ytJumpCandidates = buildList {
            ytRecentSongs.forEach {
                val pArtist = ArtistHelper.primaryArtist(it.artist)
                add(
                    RecentTrack(
                        name = it.title,
                        artist = ArtistRef(name = pArtist),
                        album = ArtistRef(name = it.album.orEmpty()),
                        image = it.artworkUrl?.let { url -> listOf(ImageDto(url, "extralarge")) }.orEmpty(),
                        url = "https://www.youtube.com/watch?v=${it.videoId}",
                    ),
                )
            }
        }
        val lastFmJumpCandidates = recentTracks.map {
            it.copy(artist = ArtistRef(name = ArtistHelper.primaryArtist(it.artist.displayName)))
        }
        // Local-first "Jump Back In": Room liked + saved as recent history
        // when Last.fm/YT history is unavailable (guest/offline).
        val localJumpCandidates = localLibrary.take(20).map {
            RecentTrack(
                name = it.name,
                artist = ArtistRef(name = ArtistHelper.primaryArtist(it.artist)),
                album = ArtistRef(name = it.album.orEmpty()),
                image = it.artworkUrl?.let { url -> listOf(ImageDto(url, "extralarge")) }.orEmpty(),
                url = it.url,
            )
        }
        val jumpCandidates = (blend(ytJumpCandidates, lastFmJumpCandidates) + localJumpCandidates)
            .distinctBy { it.artist.displayName.trim().lowercase() to it.name.trim().lowercase() }
        val jumpBackIn = diversify(jumpCandidates, { it.artist.displayName }, maxPerArtist = 2).take(15)

        // â”€â”€ Albums for you: REAL albums only. â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
        // Never derive albums from per-track `album` strings (YT track.album
        // / Last.fm recent-track album): those are usually just the single
        // name, so opening them lands on a whole different record.
        // Sources, both taste-ranked:
        //  1. Last.fm user.gettopalbums (real albums, playcount-ranked).
        //  2. YT Music artist discography Albums for our top taste artists
        //     (real MPRE entities with browseId â€” no fuzzy search needed).
        // An entry is shown only with a verified browseId, so tap always
        // opens that exact album and never a name-search guess.
        val albumArtworkRequests = Semaphore(4)
        val artistPageRequests = Semaphore(3)
        val lastFmTopAlbums = lastFmTopAlbumsDef.await()
        fun isStrictAlbumMatch(
            candidateName: String,
            candidateArtist: String?,
            wantTitle: String,
            wantArtist: String,
        ): Boolean {
            if (!candidateName.equals(wantTitle, ignoreCase = true)) return false
            if (candidateArtist.isNullOrBlank()) return true
            val wantParts = ArtistHelper.splitArtists(wantArtist).map { it.trim().lowercase() }
            if (wantParts.isEmpty()) return true
            return ArtistHelper.splitArtists(candidateArtist).any { it.trim().lowercase() in wantParts }
        }
        // YT Music real albums: Album shelf only â€” Singles/EPs are skipped so
        // a one-track "album" can never appear here.
        val lastFmArtByKey = lastFmTopAlbums.associate { top ->
            "${top.artist.trim().lowercase()}_${top.name.trim().lowercase()}" to top.artworkUrl
        }
        val ytRealAlbumsDef = async(Dispatchers.IO) { topArtists
            .filter { !it.browseId.isNullOrBlank() }
            .take(6)
            .map { artist ->
                async(Dispatchers.IO) {
                    artistPageRequests.withPermit {
                        val browseId = artist.browseId?.takeIf(String::isNotBlank)
                            ?: return@withPermit emptyList<FeedAlbum>()
                        val page = runCatching { innerTube.fetchArtistPage(browseId, artist.name) }.getOrNull()
                        page?.albums.orEmpty()
                            .filter { item ->
                                item.browseId.isNotBlank() && item.title.isNotBlank() &&
                                    (item.type == null || item.type.equals("Album", ignoreCase = true))
                            }
                            .take(3)
                            .map { item ->
                                // YT discography art is the cover; Last.fm top-album
                                // art is the backup so the card never has no cover.
                                val lastFmArt = lastFmArtByKey[
                                    "${artist.name.trim().lowercase()}_${item.title.trim().lowercase()}",
                                ]?.takeIf(ArtworkNormalizer::isRealImage)
                                FeedAlbum(
                                    title = item.title,
                                    artist = artist.name,
                                    artworkUrl = item.artworkUrl?.takeIf(ArtworkNormalizer::isRealImage)
                                        ?: lastFmArt,
                                    browseId = item.browseId,
                                )
                            }
                    }
                }
            }.awaitAll().flatten() }
        // Last.fm top albums â†’ strict YT Music verification. No exact
        // title+artist MPRE match = dropped, never guessed.
        val lastFmRealAlbumsDef = async(Dispatchers.IO) { lastFmTopAlbums
            .filter { it.name.isNotBlank() && it.artist.isNotBlank() }
            .distinctBy { "${it.artist.trim().lowercase()}_${it.name.trim().lowercase()}" }
            .take(20)
            .map { topAlbum ->
                async(Dispatchers.IO) {
                    albumArtworkRequests.withPermit {
                        val candidates = runCatching {
                            innerTube.searchAlbums("${topAlbum.name} ${topAlbum.artist}", limit = 5)
                        }.getOrNull().orEmpty()
                        val match = candidates.firstOrNull {
                            isStrictAlbumMatch(
                                candidateName = it.name,
                                candidateArtist = it.artist,
                                wantTitle = topAlbum.name,
                                wantArtist = topAlbum.artist,
                            )
                        } ?: return@withPermit null
                        FeedAlbum(
                            title = match.name,
                            artist = topAlbum.artist,
                            artworkUrl = match.artworkUrl?.takeIf(ArtworkNormalizer::isRealImage)
                                ?: topAlbum.artworkUrl?.takeIf(ArtworkNormalizer::isRealImage),
                            browseId = match.browseId,
                        )
                    }
                }
            }.awaitAll().filterNotNull() }
        val recentAlbums = blend(ytRealAlbumsDef.await(), lastFmRealAlbumsDef.await())
            .distinctBy { "${it.artist.trim().lowercase()}_${it.title.trim().lowercase()}" }
            .filter { !it.browseId.isNullOrBlank() }
            // Cover-art backfill: a card without a real cover is dropped, so
            // resolve the album page once to grab its artwork before dropping.
            .take(20)
            .map { album ->
                async(Dispatchers.IO) {
                    if (ArtworkNormalizer.isRealImage(album.artworkUrl)) {
                        album
                    } else albumArtworkRequests.withPermit {
                        val pageArt = album.browseId?.takeIf(String::isNotBlank)?.let { id ->
                            runCatching { innerTube.fetchAlbumPage(id) }.getOrNull()?.artworkUrl
                        }?.takeIf(ArtworkNormalizer::isRealImage)
                        album.copy(artworkUrl = pageArt ?: album.artworkUrl)
                    }
                }
            }.awaitAll()
            .filter { ArtworkNormalizer.isRealImage(it.artworkUrl) }
            .take(12)

        val topSpotlightArtist = topArtists.filterNot { it.name == previous?.spotlight?.artistName }
            .randomOrNull(random) ?: topArtists.firstOrNull()
        fun spotlightFor(artist: FeedArtist) = FeedSpotlight(
            artistName = artist.name,
            artworkUrl = artist.artworkUrl,
            browseId = artist.browseId,
            description = "Spotlight Artist",
            topTrackTitle = heavyRotation
                .firstOrNull { it.artist.equals(artist.name, ignoreCase = true) }
                ?.name
                ?: artistSignalTracks
                    .firstOrNull { it.artist.equals(artist.name, ignoreCase = true) }
                    ?.title,
        )
        val spotlight = topSpotlightArtist?.let { first ->
            spotlightFor(first).copy(
                more = topArtists.filterNot { it.name == first.name }.shuffled(random).take(4).map(::spotlightFor),
            )
        }

        val topArtist = topArtistNames.firstOrNull()
        // Affinity-weighted radio seed: the strongest known artist among
        // recent + liked + top picks becomes "Because you listen to X".
        fun seedScore(t: YouTubeMusicTrack, boost: Double): Double {
            val aff = ArtistHelper.splitArtists(t.artist).maxOfOrNull { affinity[it.trim().lowercase()] ?: 0.0 } ?: 0.0
            return aff * 50 + boost + (if (t.videoId.isNotBlank()) 8.0 else -10.0)
        }
        val seedCandidates = buildList {
            ytRecentSongs.forEach { add(it to seedScore(it, 12.0)) }
            ytLikedSongs.forEach { add(it to seedScore(it, 10.0)) }
            quickPicks.take(6).forEach { add(it to seedScore(it, 6.0)) }
        }.sortedByDescending { it.second }
        val personalRadioSeed = discoveryResults.firstOrNull { it.second.isNotEmpty() }?.first
            ?: seedCandidates.filter { it.first.videoId.isNotBlank() }.take(15).randomOrNull(random)?.first
            ?: heavyRotation.firstOrNull()?.takeIf { tasteProfile?.hasPersonalSignals == true }?.let { seed ->
                try {
                    innerTube.findBestMatchOrNull(seed.name, seed.artist, prefetchStreams = false)
                } catch (cancellation: CancellationException) {
                    throw cancellation
                } catch (_: Exception) {
                    null
                }
            }
        val radioSeed = personalRadioSeed ?: (quickPicks + homeSongs + charts).firstOrNull { it.videoId.isNotBlank() }
            ?: (quickPicks + homeSongs + charts).firstOrNull()
        val radioTracks = discoveryResults.firstOrNull { it.first.videoId == radioSeed?.videoId }?.second
            ?.takeIf { it.isNotEmpty() }
            ?: radioSeed?.takeIf { it.videoId.isNotBlank() }?.let { seed ->
                try {
                    recommendationRepository.relatedFor(
                        seedVideoId = seed.videoId,
                        title = seed.title,
                        artist = seed.artist,
                        limit = 15,
                        durationSeconds = seed.durationSeconds,
                    )
                } catch (cancellation: CancellationException) {
                    throw cancellation
                } catch (_: Exception) {
                    emptyList()
                }
            }.orEmpty()
        val radioArtist = radioSeed?.artist ?: topArtist
        val radioFallback = if (radioTracks.isEmpty() && !radioArtist.isNullOrBlank()) {
            try {
                innerTube.searchSongs("$radioArtist radio", limit = 15, prefetchStreams = false)
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (_: Exception) {
                emptyList()
            }
        } else emptyList()
        val becauseTracks = diversify(
            (radioTracks.ifEmpty { radioFallback }).distinctBy { it.videoId.ifBlank { it.title + "|" + it.artist } },
            YouTubeMusicTrack::artist,
            maxPerArtist = 2,
        ).take(15)
        val becauseSection = becauseTracks
            .takeIf { it.isNotEmpty() }
            ?.let { tracks ->
                FeedSectionData(
                    title = personalRadioSeed?.let { "Because you listen to ${it.artist}" } ?: "Discover something new",
                    subtitle = radioSeed?.let { "A mix inspired by ${it.title}" } ?: "Fresh tracks for your next listen",
                    items = tracks,
                )
            }

        val quickTiles = buildList {
            likedSongsId?.let {
                add(
                    FeedQuickTile(
                        title = com.lastwave.app.data.playlist.LIKED_SONGS_TITLE,
                        subtitle = "Your collection",
                        localPlaylistId = it,
                        isLiked = true,
                    ),
                )
            }
            if (isYtConnected) {
                add(FeedQuickTile(
                    title = "Liked on YT",
                    subtitle = "Your collection",
                    artworkUrl = ytLikedSongs.firstOrNull()?.artworkUrl,
                    playlistId = "yt_liked",
                    collection = "yt_liked",
                    isLiked = true,
                ))
            }
            // 2. Discover
            val savedDiscover = homePlaylists.firstOrNull { it.title.equals("Discover", ignoreCase = true) }
            add(savedDiscover?.let {
                FeedQuickTile(title = it.title, subtitle = it.author.takeIf { a -> !a.isNullOrBlank() } ?: "Made for you", artworkUrl = it.artworkUrl, playlistId = it.id)
            } ?: FeedQuickTile(title = "Discover", subtitle = "Made for you",
                artworkUrl = quickPicks.lastOrNull()?.artworkUrl ?: quickPicks.firstOrNull()?.artworkUrl, collection = "radio"))

            // 3. Discover Mix
            val savedDiscoverMix = homePlaylists.firstOrNull { it.title.contains("Discover Mix", ignoreCase = true) }
                ?: nativeShelves.flatMap { it.items }.filterIsInstance<HomeShelfItem.Playlist>()
                    .map { it.playlist }.firstOrNull { it.title.contains("Discover Mix", ignoreCase = true) }
            add(savedDiscoverMix?.let {
                FeedQuickTile(title = "Discover Mix", subtitle = it.author.takeIf { a -> !a.isNullOrBlank() } ?: "New discoveries", artworkUrl = it.artworkUrl, playlistId = it.id, collection = "discover_mix")
            } ?: FeedQuickTile(title = "Discover Mix", subtitle = "New discoveries",
                artworkUrl = ytRecentSongs.firstOrNull()?.artworkUrl, collection = "discover_mix"))

            // 4. My Mix
            val savedMyMix = homePlaylists.firstOrNull { it.title.equals("My Mix", ignoreCase = true) || it.title.equals("Mix", ignoreCase = true) }
            add(savedMyMix?.let {
                FeedQuickTile(title = it.title, subtitle = it.author.takeIf { a -> !a.isNullOrBlank() } ?: "Endless radio", artworkUrl = it.artworkUrl, playlistId = it.id, collection = "my_mix")
            } ?: FeedQuickTile(title = "My Mix", subtitle = "Endless radio",
                artworkUrl = quickPicks.firstOrNull()?.artworkUrl, collection = "my_mix"))

            add(
                FeedQuickTile(
                    title = "New Releases",
                    subtitle = "Fresh drops",
                    artworkUrl = newReleases.firstOrNull()?.artworkUrl,
                    collection = "new_releases",
                ),
            )
        }

        val defaultTasteTags = listOf("Rock", "Indie", "Pop", "Electronic", "Hip-Hop", "R&B", "Synthwave", "Alternative")
        val tasteTags = tasteProfile?.topTags.orEmpty().take(8).ifEmpty { defaultTasteTags }
        val hasPersonalContent = tasteProfile?.hasPersonalSignals == true ||
            ytRecentSongs.isNotEmpty() || ytLikedSongs.isNotEmpty() || recentTracks.isNotEmpty()
        // The podcast shelf joins the final feed; the first paint (familiar
        // picks) never waits for it.
        val podcastShelf = podcastShelfDef.await()

        val result = FeedData(
            isYtConnected = isYtConnected,
            ytAccountName = connection.accountName.takeIf { isYtConnected },
            userName = username?.takeIf { it.isNotBlank() },
            hasYtRecommendations = ytTaste?.feedTracks?.isNotEmpty() == true,
            hasYtMixes = false,
            hasPersonalContent = hasPersonalContent,
            tasteTags = tasteTags,
            nativeShelves = nativeShelves,
            homeChips = homeChips,
            homeContinuationToken = homeContinuationToken,
            ytSuggestedPlaylists = homePlaylists.filter { it.id != "LM" }.take(12),
            spotlight = spotlight,
            quickTiles = quickTiles,
            quickPicks = quickPicks,
            newReleases = newReleases,
            charts = charts,
            mixes = mixes,
            jumpBackIn = jumpBackIn,
            recentAlbums = recentAlbums,
            topArtists = topArtists,
            heavyRotation = heavyRotation,
            ytLikedSongs = ytLikedSongs,
            ytRecentSongs = ytRecentSongs,
            becauseYouListenTo = becauseSection,
            freshFinds = freshFinds,
            friends = friends.take(10),
            podcastShows = podcastShelf?.shows.orEmpty(),
            podcastShelfTitle = podcastShelf?.title,
            lastUpdatedMillis = System.currentTimeMillis(),
        )
        ensureActive()
        cached = cacheKey to result
        result
    }

}
