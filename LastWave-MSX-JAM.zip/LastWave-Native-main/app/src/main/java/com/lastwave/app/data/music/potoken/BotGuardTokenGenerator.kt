package com.lastwave.app.data.music.potoken

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.LruCache
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.MainThread
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

data class PoTokenResult(
    val playerToken: String,
    val sessionToken: String,
)

/**
 * Headless BotGuard engine that mints valid YouTube Proof-of-Origin (`po_token`)
 * values by running Google's JS challenge in a lightweight Android WebView.
 */
object BotGuardTokenGenerator {
    private const val TAG = "BotGuardTokenGen"
    private const val CREATE_URL = "https://www.youtube.com/api/jnn/v1/Create"
    private const val GENERATE_IT_URL = "https://www.youtube.com/api/jnn/v1/GenerateIT"
    private const val REQUEST_KEY = "O43z0dpjhgX20SCx4KAo"
    private const val JS_BRIDGE = "BotGuardBridge"

    // The jnn endpoints are a gRPC-web API keyed by the YouTube web player's
    // public API key. Without these headers Create answers {"error": ...},
    // so the engine never armed and was rebuilt (and torn down) every song.
    private const val GOOGLE_API_KEY = "AIzaSyDyT5W0Jh49F30Pqqtyfdf7pDLFKLJoAnw"
    private const val DESKTOP_USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/131.0.0.0 Safari/537.36"
    private val JSPB = "application/json+protobuf".toMediaType()

    /** Delay between blanking a retired WebView and destroying it. */
    private const val WEBVIEW_DESTROY_DELAY_MS = 500L
    private val mainHandler = Handler(Looper.getMainLooper())

    private class BotGuardHttpException(val code: Int, endpoint: String) :
        java.io.IOException("$endpoint answered HTTP $code")

    /** One jnn call with the headers the API requires; non-200 is an error, never a body to parse. */
    private fun callBotGuardApi(url: String, body: String, endpoint: String): String {
        val request = Request.Builder()
            .url(url)
            .post(body.toRequestBody(JSPB))
            .header("Content-Type", "application/json+protobuf")
            .header("Accept", "application/json")
            .header("x-goog-api-key", GOOGLE_API_KEY)
            .header("x-user-agent", "grpc-web-javascript/0.1")
            .header("User-Agent", DESKTOP_USER_AGENT)
            .build()
        return httpClient.newCall(request).execute().use { response ->
            if (response.code != 200) throw BotGuardHttpException(response.code, endpoint)
            response.body?.string().orEmpty()
        }
    }

    // A cold start must fit: WebView boot + Create HTTPS call + JS BotGuard +
    // GenerateIT call + minter creation, strictly serial. The old 1.5s budget
    // was physically impossible on anything but a warm cache + fast network,
    // so preWarm nearly always timed out, destroyed the freshly built engine,
    // and forced every first play to rebuild it from scratch (constant
    // WebView churn + wasted network + slower first-play).
    private const val COLD_START_TIMEOUT_MS = 10_000L
    private const val WARM_TIMEOUT_MS = 3_000L

    // Consecutive full-bootstrap failures (WebView + Create + JS + GenerateIT)
    // mean the flow is systematically broken — e.g. YouTube changed a
    // challenge format — not one unlucky song. Past the threshold, minting
    // pauses and playback continues on the fallback resolvers instead of
    // rebuilding a doomed WebView engine (network + memory churn) per song.
    // Any success resets; expiry retries once and re-arms only on failure.
    private const val BOOTSTRAP_FAILURE_THRESHOLD = 3
    private const val BOOTSTRAP_COOLDOWN_MS = 15 * 60 * 1000L
    @Volatile private var bootstrapCooldownUntilMs = 0L
    private var consecutiveBootstrapFailures = 0
    private var cooldownNotified = false

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val mutex = Mutex()
    private var appContext: Context? = null
    private var engine: BotGuardEngine? = null
    private var engineSessionId: String? = null
    private var cachedSessionToken: String? = null
    private var engineReady = false
    private var permanentlyBroken = false

    private val playerTokenCache = LruCache<String, String>(200)

    @MainThread
    fun initialize(context: Context) {
        if (appContext != null) return
        appContext = context.applicationContext
        Log.d(TAG, "BotGuard Token Generator initialized")
    }

    suspend fun preWarm(sessionId: String = "lastwave_session") {
        val ctx = appContext ?: return
        if (permanentlyBroken || sessionId.isBlank() || !hasUsableWebView()) return
        if (System.currentTimeMillis() < bootstrapCooldownUntilMs) return
        runCatching {
            withTimeoutOrNull(COLD_START_TIMEOUT_MS) {
                ensureEngineReady(ctx, sessionId)
            }
        }
    }

    suspend fun mintToken(
        videoId: String,
        sessionId: String = "lastwave_session",
    ): PoTokenResult? {
        val ctx = appContext ?: return null
        if (permanentlyBroken || !hasUsableWebView()) return null
        if (System.currentTimeMillis() < bootstrapCooldownUntilMs) return null

        mutex.withLock {
            if (isEngineReadyForSession(sessionId)) {
                val cachedPlayer = playerTokenCache.get(videoId)
                val sessionToken = cachedSessionToken
                if (cachedPlayer != null && sessionToken != null) {
                    return PoTokenResult(playerToken = cachedPlayer, sessionToken = sessionToken)
                }
            }
        }

        val timeout = if (!isEngineReadyForSession(sessionId)) COLD_START_TIMEOUT_MS else WARM_TIMEOUT_MS

        return try {
            withTimeoutOrNull(timeout) {
                val result = mintTokenInternal(ctx, videoId, sessionId, forceNewEngine = false)
                mutex.withLock {
                    playerTokenCache.put(videoId, result.playerToken)
                }
                result
            }
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (e: Exception) {
            Log.w(TAG, "PO Token minting failed for $videoId: ${e.message}")
            null
        }
    }

    private suspend fun ensureEngineReady(ctx: Context, sessionId: String) {
        getOrCreateEngine(ctx, sessionId, forceNewEngine = false)
    }

    private suspend fun mintTokenInternal(
        ctx: Context,
        videoId: String,
        sessionId: String,
        forceNewEngine: Boolean,
    ): PoTokenResult {
        val (eng, sessionTok, wasNew) = getOrCreateEngine(ctx, sessionId, forceNewEngine)
        val playerTok = try {
            eng.mint(videoId)
        } catch (e: Throwable) {
            if (wasNew) throw e
            Log.w(TAG, "Mint failed on existing engine; retrying with fresh engine")
            return mintTokenInternal(ctx, videoId, sessionId, forceNewEngine = true)
        }
        return PoTokenResult(playerToken = playerTok, sessionToken = sessionTok)
    }

    private suspend fun getOrCreateEngine(
        ctx: Context,
        sessionId: String,
        forceNewEngine: Boolean,
    ): Triple<BotGuardEngine, String, Boolean> = mutex.withLock {
        val needsNew = forceNewEngine || !isEngineReadyForSession(sessionId)
        if (needsNew) {
            withContext(Dispatchers.Main) {
                engine?.close()
            }
            engine = null
            engineSessionId = null
            cachedSessionToken = null
            engineReady = false
            playerTokenCache.evictAll()

            try {
                val newEngine = BotGuardEngine.create(ctx)
                val newSessionToken = try {
                    newEngine.mint(sessionId)
                } catch (error: Throwable) {
                    withContext(Dispatchers.Main) {
                        newEngine.close()
                    }
                    throw error
                }

                engine = newEngine
                engineSessionId = sessionId
                cachedSessionToken = newSessionToken
                engineReady = true
                consecutiveBootstrapFailures = 0
                bootstrapCooldownUntilMs = 0L
                cooldownNotified = false
            } catch (cancellation: CancellationException) {
                throw cancellation
            } catch (error: Throwable) {
                // A refused or unrecognised challenge is a fact about the API
                // right now, not one unlucky song: retrying it only rebuilds a
                // WebView per track, which is the churn that crashed the app.
                val refusedOutright = error is ChallengeFormatException ||
                    (error is BotGuardHttpException && error.code in 400..499)
                recordBootstrapFailure(refusedOutright)
                throw error
            }
        }

        Triple(requireNotNull(engine), requireNotNull(cachedSessionToken), needsNew)
    }

    /** Mutex-guarded: only called from [getOrCreateEngine]'s locked section. */
    private fun recordBootstrapFailure(refusedOutright: Boolean = false) {
        consecutiveBootstrapFailures++
        if ((refusedOutright || consecutiveBootstrapFailures >= BOOTSTRAP_FAILURE_THRESHOLD) &&
            System.currentTimeMillis() >= bootstrapCooldownUntilMs
        ) {
            bootstrapCooldownUntilMs = System.currentTimeMillis() + BOOTSTRAP_COOLDOWN_MS
            if (!cooldownNotified) {
                cooldownNotified = true
                Log.w(
                    TAG,
                    "BotGuard bootstrap failed ${consecutiveBootstrapFailures}x in a row; " +
                        "pausing PO-token minting for ${BOOTSTRAP_COOLDOWN_MS / 60_000} min " +
                        "(playback continues via fallback resolvers)",
                )
            }
        }
    }

    /**
     * Drops the headless WebView engine (tens of MB of in-process Chromium)
     * when Android reports memory pressure while LastWave sits in the
     * background. The next mint rebuilds it on demand, exactly like after
     * expiry. Never touches an engine another call is using: waits for the
     * mutex.
     */
    suspend fun releaseForMemoryPressure() {
        mutex.withLock {
            val current = engine ?: return
            withContext(Dispatchers.Main) { current.close() }
            engine = null
            engineSessionId = null
            cachedSessionToken = null
            engineReady = false
            playerTokenCache.evictAll()
            Log.i(TAG, "BotGuard engine released for memory pressure")
        }
    }

    private fun isEngineReadyForSession(sessionId: String): Boolean =
        engineReady && engineSessionId == sessionId && cachedSessionToken != null && engine?.isExpired == false

    private fun hasUsableWebView(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return true
        return runCatching { WebView.getCurrentWebViewPackage() != null }
            .onFailure { Log.w(TAG, "Unable to inspect WebView provider", it) }
            .getOrDefault(false)
    }

    private class BotGuardEngine private constructor(
        private val webView: WebView,
        private val readyDeferred: CompletableDeferred<BotGuardEngine>,
    ) {
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
        private val closed = AtomicBoolean(false)
        private val pendingMints = ConcurrentHashMap<String, CompletableDeferred<String>>()
        @Volatile private var expiresAtMs: Long = System.currentTimeMillis() + 50 * 60 * 1000L

        /** Expired, closed, or its renderer died: never reuse, rebuild instead. */
        val isExpired: Boolean get() = closed.get() || System.currentTimeMillis() > expiresAtMs

        /**
         * The WebView renderer crashed or was reclaimed under memory pressure.
         * Without handling this, Android kills the whole app process.
         * Fail anything waiting and drop the dead WebView; the next mint
         * rebuilds a fresh engine.
         */
        @MainThread
        fun onRendererGone() {
            Log.w(TAG, "BotGuard WebView renderer gone; engine will be rebuilt on demand")
            readyDeferred.completeExceptionally(IllegalStateException("BotGuard renderer gone"))
            close()
        }

        fun startBootstrap() {
            scope.launch {
                runCatching {
                    val html = withContext(Dispatchers.IO) {
                        webView.context.assets.open("po_token.html").bufferedReader().use { it.readText() }
                    }
                    val patched = html.replaceFirst("</script>", "\n$JS_BRIDGE.onPageLoaded()</script>")
                    if (closed.get()) return@runCatching
                    webView.loadDataWithBaseURL("https://www.youtube.com", patched, "text/html", "utf-8", null)
                }.onFailure { error ->
                    Log.e(TAG, "BotGuard bootstrap failed", error)
                    readyDeferred.completeExceptionally(error)
                }
            }
        }

        @JavascriptInterface
        fun onPageLoaded() {
            scope.launch(Dispatchers.IO) {
                runCatching {
                    val response = callBotGuardApi(CREATE_URL, "[ \"$REQUEST_KEY\" ]", "Create")
                    val challengeJson = parseCreateChallenge(response)

                    withContext(Dispatchers.Main) {
                        if (closed.get()) return@withContext
                        webView.evaluateJavascript(
                            """
                            try {
                                var data = $challengeJson;
                                runBotGuard(data).then(function(r) {
                                    window.webPoSignalOutput = r.webPoSignalOutput;
                                    $JS_BRIDGE.onBotGuardReady(r.botguardResponse);
                                }, function(e) {
                                    $JS_BRIDGE.onFatalError(e + "\n" + e.stack);
                                });
                            } catch(e) { $JS_BRIDGE.onFatalError(e + "\n" + e.stack); }
                            """.trimIndent(),
                            null,
                        )
                    }
                }.onFailure { error ->
                    Log.e(TAG, "Create challenge request failed", error)
                    readyDeferred.completeExceptionally(error)
                }
            }
        }

        @JavascriptInterface
        fun onBotGuardReady(botguardResponse: String) {
            scope.launch(Dispatchers.IO) {
                runCatching {
                    val safeResponse = botguardResponse.replace("\\", "\\\\").replace("\"", "\\\"")
                    val response = callBotGuardApi(
                        GENERATE_IT_URL,
                        "[ \"$REQUEST_KEY\", \"$safeResponse\" ]",
                        "GenerateIT",
                    )
                    val (tokenU8, lifetimeSec) = parseIntegrityToken(response)
                    expiresAtMs = System.currentTimeMillis() + (lifetimeSec - 300L) * 1000L

                    withContext(Dispatchers.Main) {
                        if (closed.get()) return@withContext
                        webView.evaluateJavascript(
                            """
                            try {
                                createPoTokenMinter(window.webPoSignalOutput, $tokenU8).then(function() {
                                    $JS_BRIDGE.onMinterReady();
                                }).catch(function(e) {
                                    $JS_BRIDGE.onFatalError(e + "\n" + (e.stack || ''));
                                });
                            } catch(e) { $JS_BRIDGE.onFatalError(e + "\n" + e.stack); }
                            """.trimIndent(),
                            null,
                        )
                    }
                }.onFailure { error ->
                    Log.e(TAG, "GenerateIT request failed", error)
                    readyDeferred.completeExceptionally(error)
                }
            }
        }

        @JavascriptInterface
        fun onMinterReady() {
            readyDeferred.complete(this@BotGuardEngine)
        }

        @JavascriptInterface
        fun onFatalError(error: String) {
            Log.e(TAG, "BotGuard JS fatal error: $error")
            readyDeferred.completeExceptionally(IllegalStateException("BotGuard JS error: $error"))
        }

        suspend fun mint(identifier: String): String = withContext(Dispatchers.Main) {
            // Another caller may have replaced (closed) this engine meanwhile;
            // never drive a destroyed WebView.
            if (closed.get()) throw IllegalStateException("BotGuard engine closed")
            // computeIfAbsent so two concurrent mints for the same identifier
            // share one deferred instead of the second orphaning the first
            // (which used to leave an awaiter hanging until its outer timeout).
            val deferred = pendingMints.computeIfAbsent(identifier) { CompletableDeferred() }
            val u8Arg = stringToJsUint8Array(identifier)

            webView.evaluateJavascript(
                """
                try {
                    obtainPoToken($u8Arg).then(function(u8) {
                        $JS_BRIDGE.onMintOk(${jsStringLiteral(identifier)}, Array.from(u8).join(","));
                    }).catch(function(e) {
                        $JS_BRIDGE.onMintErr(${jsStringLiteral(identifier)}, e + "\n" + (e.stack || ''));
                    });
                } catch(e) { $JS_BRIDGE.onMintErr(${jsStringLiteral(identifier)}, e + "\n" + e.stack); }
                """.trimIndent(),
                null,
            )
            deferred.await()
        }

        @JavascriptInterface
        fun onMintOk(identifier: String, csvBytes: String) {
            // A malformed bridge payload must fail this mint, never the
            // bridge thread (an orphaned deferred would hang until timeout).
            val base64 = runCatching { commaSeparatedBytesToBase64(csvBytes) }.getOrNull()
            if (base64 == null) {
                pendingMints.remove(identifier)
                    ?.completeExceptionally(IllegalStateException("Mint payload was not numeric CSV"))
            } else {
                pendingMints.remove(identifier)?.complete(base64)
            }
        }

        @JavascriptInterface
        fun onMintErr(identifier: String, error: String) {
            Log.e(TAG, "Mint error for $identifier: $error")
            pendingMints.remove(identifier)?.completeExceptionally(IllegalStateException("Mint error: $error"))
        }

        fun close() {
            if (closed.compareAndSet(false, true)) {
                // Fail in-flight mints so their awaiters surface an error
                // instead of hanging forever against a destroyed WebView,
                // and stop queued engine work.
                pendingMints.values.forEach {
                    it.completeExceptionally(IllegalStateException("BotGuard engine closed"))
                }
                pendingMints.clear()
                runCatching { scope.cancel() }
                // Torn down on the main thread, with destroy() a moment later:
                // close() is reached from a failing bootstrap while the page's
                // own bridge call and Chromium's IO threads are still unwinding,
                // and destroying the WebView under them crashed the whole app
                // natively inside libwebviewchromium a few seconds into a song.
                mainHandler.post {
                    runCatching { webView.stopLoading() }
                    runCatching { webView.removeJavascriptInterface(JS_BRIDGE) }
                    runCatching { webView.loadUrl("about:blank") }
                    mainHandler.postDelayed({ runCatching { webView.destroy() } }, WEBVIEW_DESTROY_DELAY_MS)
                }
            }
        }

        /** Escapes a value interpolated into a JS string literal inside
         *  evaluateJavascript — quotes/backslashes/newlines would otherwise
         *  produce broken script (or inject it). */
        private fun jsStringLiteral(value: String): String = "\"" +
            value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r") +
            "\""

        companion object {
            @SuppressLint("SetJavaScriptEnabled")
            suspend fun create(context: Context): BotGuardEngine = withContext(Dispatchers.Main) {
                val readyDeferred = CompletableDeferred<BotGuardEngine>()
                val webView = WebView(context.applicationContext).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    // The same browser identity the jnn requests present.
                    settings.userAgentString = DESKTOP_USER_AGENT
                }
                val engine = BotGuardEngine(webView, readyDeferred)
                webView.webViewClient = object : WebViewClient() {
                    // Returning true keeps the app alive when the headless
                    // renderer dies (crash or low-memory kill); the default
                    // (false) makes the framework kill the whole process.
                    override fun onRenderProcessGone(
                        view: WebView?,
                        detail: android.webkit.RenderProcessGoneDetail?,
                    ): Boolean {
                        runCatching { engine.onRendererGone() }
                        return true
                    }
                }
                webView.addJavascriptInterface(engine, JS_BRIDGE)
                engine.startBootstrap()
                try {
                    readyDeferred.await()
                } catch (t: Throwable) {
                    // Bootstrap is wrapped in caller-side withTimeoutOrNull — on
                    // timeout/cancellation the coroutine aborts HERE, and without
                    // this cleanup the freshly created WebView (a full rendering
                    // pipeline) leaked every single time. Repeated timeouts during
                    // slow-network periods compounded into real memory pressure.
                    engine.close()
                    throw t
                }
            }
        }
    }
}
