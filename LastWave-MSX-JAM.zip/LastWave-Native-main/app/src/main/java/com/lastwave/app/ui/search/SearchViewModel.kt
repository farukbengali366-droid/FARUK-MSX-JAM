package com.lastwave.app.ui.search

import androidx.compose.runtime.Immutable
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lastwave.app.data.generate.LocalAudioFormats
import com.lastwave.app.data.generate.isLocalAudioPath
import com.lastwave.app.data.search.SearchHistoryRepository
import com.lastwave.app.data.search.SearchRepository
import com.lastwave.app.data.search.SearchResultItem
import com.lastwave.app.data.search.SearchTab
import com.lastwave.app.playback.MediaType
import com.lastwave.app.playback.MusicPlayer
import com.lastwave.app.playback.PlayableTrack
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class SearchStatus { IDLE, LOADING, EMPTY, RESULTS }

@Immutable
data class SearchUiState(
    val query: String = "",
    val tab: SearchTab = SearchTab.TRACKS,
    val status: SearchStatus = SearchStatus.IDLE,
    val results: List<SearchResultItem> = emptyList(),
    val suggestions: List<String> = emptyList(),
    val songSuggestions: List<SearchResultItem> = emptyList(),
    val recentSearches: List<String> = emptyList(),
    val isShowingSuggestions: Boolean = false,
)

/**
 * YouTube Music & Last.fm search with live auto-complete suggestions,
 * persistent search history, debounced search, and multi-tab results.
 */
@HiltViewModel
class SearchViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: SearchRepository,
    private val historyRepository: SearchHistoryRepository,
    private val musicPlayer: MusicPlayer,
) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private var debounceJob: Job? = null
    private var suggestionsJob: Job? = null
    private var searchJob: Job? = null
    private var searchQueueJob: Job? = null
    private var lastIssuedQuery: String = ""

    init {
        // Opened with a ready-made query (e.g. from music recognition).
        savedStateHandle.get<String>("q")?.takeIf { it.isNotBlank() }?.let(::executeSearch)
        viewModelScope.launch {
            historyRepository.history.collect { history ->
                _uiState.update { it.copy(recentSearches = history) }
            }
        }
    }

    fun setQuery(query: String) {
        _uiState.update {
            it.copy(query = query, songSuggestions = emptyList(), isShowingSuggestions = query.isNotBlank())
        }
        debounceJob?.cancel()
        suggestionsJob?.cancel()

        if (query.isBlank()) {
            musicPlayer.cancelSearchResultWarm()
            searchJob?.cancel()
            _uiState.update {
                it.copy(
                    status = SearchStatus.IDLE,
                    results = emptyList(),
                    suggestions = emptyList(),
                    isShowingSuggestions = false,
                )
            }
            return
        }

        // Fast suggestions debounce (120ms)
        suggestionsJob = viewModelScope.launch {
            delay(120)
            val suggestions = repository.getSuggestions(query)
            if (_uiState.value.query == query) {
                _uiState.update { it.copy(suggestions = suggestions) }
            }
        }

        // Full search results debounce (350ms)
        debounceJob = viewModelScope.launch {
            delay(350)
            triggerSearch(query, saveToHistory = false)
        }
    }

    fun setTab(tab: SearchTab) {
        if (_uiState.value.tab == tab) return
        _uiState.update {
            it.copy(
                tab = tab,
                songSuggestions = emptyList(),
                isShowingSuggestions = false,
                results = emptyList(),
                status = if (it.query.isBlank()) SearchStatus.IDLE else SearchStatus.LOADING,
            )
        }
        val q = _uiState.value.query
        if (q.isNotBlank()) {
            debounceJob?.cancel()
            suggestionsJob?.cancel()
            triggerSearch(q, saveToHistory = false)
        }
    }

    fun searchNow() {
        val q = _uiState.value.query
        if (q.isBlank()) return
        executeSearch(q)
    }

    fun executeSearch(query: String) {
        val trimmed = query.trim()
        if (trimmed.isBlank()) return
        debounceJob?.cancel()
        suggestionsJob?.cancel()
        historyRepository.add(trimmed)
        _uiState.update {
            it.copy(
                query = trimmed,
                isShowingSuggestions = false,
            )
        }
        triggerSearch(trimmed, saveToHistory = true)
    }

    private fun triggerSearch(query: String, saveToHistory: Boolean) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            runSearch(query, saveToHistory)
        }
    }

    fun removeRecentSearch(query: String) {
        historyRepository.remove(query)
    }

    fun clearRecentSearches() {
        historyRepository.clear()
    }

    fun dismissSuggestions() {
        _uiState.update { it.copy(isShowingSuggestions = false) }
    }

    fun playResult(item: SearchResultItem) {
        searchQueueJob?.cancel()
        val tab = _uiState.value.tab
        when (tab) {
            SearchTab.TRACKS -> {
                val selected = item.toPlayableTrack()
                // Start immediately. Similar song radio queue loads and extends infinitely.
                musicPlayer.play(selected, sourceLabel = "Search", startRadio = true)
            }
            SearchTab.LOCAL -> {
                val id = item.entityId
                if (id != null && id.startsWith("offline_playlist:")) {
                    val plId = id.removePrefix("offline_playlist:")
                    viewModelScope.launch {
                        val tracks = repository.localTracksForOfflinePlaylist(plId)
                        if (tracks.isNotEmpty()) {
                            musicPlayer.playQueue(
                                tracks = tracks.map { t ->
                                    PlayableTrack(
                                        title = t.name,
                                        artist = t.artist,
                                        album = t.album,
                                        artworkUrl = t.artworkUrl,
                                        playbackUrl = t.url,
                                        playbackMimeType = LocalAudioFormats.mimeFor(t.url),
                                        durationMs = t.durationMs,
                                        trackNumber = t.trackNumber,
                                    )
                                },
                                startIndex = 0,
                                sourceLabel = item.name,
                                enableRadioContinuation = false,
                            )
                        }
                    }
                } else {
                    val localItems = _uiState.value.results.filter { isLocalAudioPath(it.url) }
                    val targetIdx = localItems.indexOfFirst { it.url == item.url }.coerceAtLeast(0)
                    val queue = if (localItems.isNotEmpty()) localItems else listOf(item)
                    musicPlayer.playQueue(
                        tracks = queue.map { it.toPlayableTrack() },
                        startIndex = targetIdx,
                        sourceLabel = "Local Search",
                        enableRadioContinuation = false,
                    )
                }
            }
            SearchTab.ARTISTS, SearchTab.ALBUMS -> viewModelScope.launch {
                val tracks = runCatching { repository.songsFor(item) }.getOrDefault(emptyList())
                if (tracks.isNotEmpty()) {
                    musicPlayer.playQueue(tracks.map { track ->
                        PlayableTrack(
                            title = track.title,
                            artist = track.artist.takeUnless { it == "Unknown artist" } ?: item.artist ?: item.name,
                            album = track.album ?: if (tab == SearchTab.ALBUMS) item.name else null,
                            artworkUrl = track.artworkUrl ?: item.artworkUrl,
                            videoId = track.videoId,
                            durationMs = track.durationSeconds?.takeIf { it > 0 }?.times(1_000L),
                        )
                    }, sourceLabel = "Search")
                }
            }
            SearchTab.PODCASTS -> {
                val selected = item.toPlayableTrack(podcast = true)
                musicPlayer.playPodcastQueue(listOf(selected), startIndex = 0, sourceLabel = "Search")
            }
            SearchTab.PLAYLISTS, SearchTab.USERS -> Unit
        }
    }

    private suspend fun runSearch(query: String, saveToHistory: Boolean) {
        val tab = _uiState.value.tab
        lastIssuedQuery = query
        _uiState.update { it.copy(status = SearchStatus.LOADING) }
        if (saveToHistory) {
            historyRepository.add(query)
        }
        try {
            val results = repository.search(tab, query)
            // Stale-response guard: discard if the user has typed something
            // new since this call was issued.
            if (lastIssuedQuery != query || _uiState.value.query.trim() != query.trim() || _uiState.value.tab != tab) return
            _uiState.update {
                it.copy(
                    status = if (results.isEmpty()) SearchStatus.EMPTY else SearchStatus.RESULTS,
                    results = results,
                    songSuggestions = if (tab == SearchTab.TRACKS) results.take(5) else emptyList(),
                )
            }
            if (tab == SearchTab.TRACKS) {
                musicPlayer.warmLikelyPlays(results.map { it.toPlayableTrack() })
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            if (lastIssuedQuery != query || _uiState.value.query.trim() != query.trim() || _uiState.value.tab != tab) return
            _uiState.update { it.copy(status = SearchStatus.EMPTY, results = emptyList()) }
        }
    }

    fun clearQuery() {
        musicPlayer.cancelSearchResultWarm()
        debounceJob?.cancel()
        suggestionsJob?.cancel()
        searchJob?.cancel()
        _uiState.update {
            it.copy(
                query = "",
                status = SearchStatus.IDLE,
                results = emptyList(),
                suggestions = emptyList(),
                songSuggestions = emptyList(),
                isShowingSuggestions = false,
            )
        }
    }
}

/** Taps, menus and warm-ups keep the same recording rather than resolving its title again. */
internal fun SearchResultItem.toPlayableTrack(podcast: Boolean = false): PlayableTrack {
    val isLocal = isLocalAudioPath(url)
    return PlayableTrack(
        title = name,
        artist = artist.orEmpty().ifBlank { if (podcast) "Podcast" else "" },
        album = if (podcast) null else subtitle,
        artworkUrl = artworkUrl,
        videoId = videoId,
        playbackUrl = if (isLocal) url else null,
        playbackMimeType = if (isLocal) LocalAudioFormats.mimeFor(url) else null,
        durationMs = durationMs,
        trackNumber = trackNumber,
        mediaType = if (podcast) MediaType.PODCAST_EPISODE else MediaType.SONG,
        showId = if (podcast) showId else null,
    )
}
